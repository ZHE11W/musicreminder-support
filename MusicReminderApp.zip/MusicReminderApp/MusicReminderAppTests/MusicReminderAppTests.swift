//
//  MusicReminderAppTests.swift
//  MusicReminderAppTests
//
//  Created by 王哲 on 2025/8/27.
//

import Testing
@testable import MusicReminderApp

struct MusicReminderAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
