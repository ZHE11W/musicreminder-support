#!/usr/bin/env python3
"""
创建严格符合iOS Critical Alert规范的音频文件
iOS Critical Alert限制：
- 最大30秒
- 文件大小不超过1MB
- 采样率不超过48kHz
- 单声道或立体声
"""

import numpy as np
import wave

def create_ios_critical_alert():
    # 严格的iOS规范参数
    sample_rate = 22050  # 22.05kHz，安全的采样率
    duration = 30  # 30秒，iOS最大限制
    frequency = 1000  # 1000Hz，清晰的频率
    
    # 创建时间轴
    t = np.linspace(0, duration, int(sample_rate * duration), False)
    
    # 创建间歇性响铃模式：0.5秒响，0.5秒停，循环
    beep_duration = 0.5  # 响铃持续时间
    silence_duration = 0.5  # 静音持续时间
    cycle_duration = beep_duration + silence_duration  # 总周期时间
    
    # 生成音频波形
    audio = np.zeros_like(t)
    
    for i, time in enumerate(t):
        cycle_position = time % cycle_duration
        if cycle_position < beep_duration:
            # 在响铃阶段，生成正弦波
            audio[i] = 0.3 * np.sin(2 * np.pi * frequency * time)
        # 在静音阶段保持为0
    
    # 转换为16位整数
    audio_int = (audio * 32767).astype(np.int16)
    
    # 保存为WAV文件
    with wave.open('MusicReminderApp/critical_alert.wav', 'w') as wav_file:
        wav_file.setnchannels(1)  # 单声道
        wav_file.setsampwidth(2)  # 16位
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(audio_int.tobytes())
    
    file_size = len(audio_int.tobytes()) / 1024  # KB
    print(f"✅ 创建了iOS Critical Alert音频文件: critical_alert.wav")
    print(f"📊 文件大小: {file_size:.1f} KB")
    print(f"⏱️ 时长: {duration} 秒")
    print(f"🔊 采样率: {sample_rate} Hz")
    print(f"🎯 严格符合iOS Critical Alert规范")

if __name__ == "__main__":
    create_ios_critical_alert()
