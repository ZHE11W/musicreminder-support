import UIKit

class MainTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTabBar()
        setupViewControllers()
    }
    
    // MARK: - 设置标签栏
    private func setupTabBar() {
        // 设置标签栏样式 - 模仿苹果提醒事项
        tabBar.backgroundColor = .systemBackground
        tabBar.tintColor = .systemBlue
        tabBar.unselectedItemTintColor = .systemGray
        
        // iOS 15+ 标签栏样式
        if #available(iOS 15.0, *) {
            let appearance = UITabBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = .systemBackground

            // 调整标签栏文字大小
            let normalTextAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14, weight: .medium)
            ]
            let selectedTextAttributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 14, weight: .semibold)
            ]

            appearance.stackedLayoutAppearance.normal.titleTextAttributes = normalTextAttributes
            appearance.stackedLayoutAppearance.selected.titleTextAttributes = selectedTextAttributes
            appearance.inlineLayoutAppearance.normal.titleTextAttributes = normalTextAttributes
            appearance.inlineLayoutAppearance.selected.titleTextAttributes = selectedTextAttributes
            appearance.compactInlineLayoutAppearance.normal.titleTextAttributes = normalTextAttributes
            appearance.compactInlineLayoutAppearance.selected.titleTextAttributes = selectedTextAttributes

            tabBar.standardAppearance = appearance
            tabBar.scrollEdgeAppearance = appearance
        } else {
            // iOS 14及以下的字体设置
            UITabBarItem.appearance().setTitleTextAttributes([
                .font: UIFont.systemFont(ofSize: 14, weight: .medium)
            ], for: .normal)
            UITabBarItem.appearance().setTitleTextAttributes([
                .font: UIFont.systemFont(ofSize: 14, weight: .semibold)
            ], for: .selected)
        }
    }
    
    // MARK: - 设置视图控制器
    private func setupViewControllers() {
        
        // 🔔 提醒页面
        let reminderVC = ReminderViewController()
        let reminderNav = UINavigationController(rootViewController: reminderVC)
        reminderNav.tabBarItem = UITabBarItem(
            title: "提醒",
            image: UIImage(systemName: "bell"),
            selectedImage: UIImage(systemName: "bell.fill")
        )
        
        // 📝 记录页面
        let recordVC = RecordViewController()
        let recordNav = UINavigationController(rootViewController: recordVC)
        recordNav.tabBarItem = UITabBarItem(
            title: "记录",
            image: UIImage(systemName: "note.text"),
            selectedImage: UIImage(systemName: "note.text.badge.plus")
        )
        
        // 设置视图控制器数组
        viewControllers = [reminderNav, recordNav]
        
        // 默认选中提醒页面
        selectedIndex = 0
    }
    
    // MARK: - 标签栏样式配置
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // 确保标签栏可见
        tabBar.isHidden = false
    }
}
