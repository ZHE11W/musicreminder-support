import Foundation
import AVFoundation

// 生成一个喜庆、响度高、更加醒目的闹铃：celebration_loud.wav（30秒）
// 优先写入沙盒 Documents，AlarmPlayer 会优先使用该文件
final class AlarmSoundGenerator {

    static func generateCelebrationLoudIfNeededAsync() {
        DispatchQueue.global(qos: .utility).async {
            self.generateCelebrationLoudIfNeeded()
        }
    }

    static func generateCelebrationLoudIfNeeded() {
        guard let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("❌ 无法获取Documents目录")
            return
        }
        let outURL = documentsURL.appendingPathComponent("celebration_loud.wav")
        if FileManager.default.fileExists(atPath: outURL.path) {
            print("✅ 已存在庆典铃声: \(outURL.lastPathComponent)")
            return
        }

        do {
            // 44.1kHz, 16-bit, 单声道 PCM
            let settings: [String: Any] = [
                AVFormatIDKey: kAudioFormatLinearPCM,
                AVSampleRateKey: 44100.0,
                AVNumberOfChannelsKey: 1,
                AVLinearPCMBitDepthKey: 16,
                AVLinearPCMIsFloatKey: false,
                AVLinearPCMIsBigEndianKey: false
            ]

            let sampleRate: Double = 44100.0
            let durationSec: Double = 30.0
            let totalFrames = AVAudioFrameCount(sampleRate * durationSec)

            let audioFile = try AVAudioFile(forWriting: outURL, settings: settings)
            guard let buffer = AVAudioPCMBuffer(pcmFormat: audioFile.processingFormat, frameCapacity: totalFrames) else {
                print("❌ 创建音频缓冲失败")
                return
            }
            buffer.frameLength = totalFrames

            // 生成“喜庆 + 强存在感”的节奏与和弦
            // - 120 BPM，一拍=0.5s；每小节4拍；30秒=60拍
            // - 下拍采用 C大三和弦（C5-E5-G5）+ 八度，包络突出的attack/decay，时长约0.35s
            // - 次拍给一个高音撞击（C6/G6短促），时长约0.15s
            // - 总体增益高但避免削波
            let twoPi = 2.0 * Double.pi
            let bpm: Double = 120.0
            let secondsPerBeat: Double = 60.0 / bpm // 0.5s
            let chordBurstSec: Double = 0.35
            let pingBurstSec: Double = 0.15

            // 频率设置（Hz）
            let C5 = 523.25
            let E5 = 659.25
            let G5 = 783.99
            let C6 = 1046.50
            let G6 = 1567.98

            // 振幅设置
            let chordAmp: Double = 0.85 // 主和弦主导（注意包络避免削波）
            let pingAmp: Double = 0.75

            // 包络函数：快速起音+指数衰减（更“喜庆/打击乐”）
            func burstEnvelope(t: Double, length: Double) -> Double {
                if t < 0 || t > length { return 0 }
                let attack = min(0.015, length * 0.2)  // 15ms attack
                let decay = max(0.035, length - attack)
                if t < attack {
                    return t / attack
                } else {
                    let dt = t - attack
                    // 指数衰减，保留一定尾音
                    return exp(-4.0 * dt / decay)
                }
            }

            // 写入采样
            if let ch = buffer.floatChannelData?[0] {
                var frameIndex: Int = 0
                let total = Int(totalFrames)
                while frameIndex < total {
                    let t = Double(frameIndex) / sampleRate
                    // 当前处于第几拍、拍内相对时间
                    let beatIdx = Int(floor(t / secondsPerBeat))
                    let tInBeat = t - Double(beatIdx) * secondsPerBeat

                    var sample: Double = 0.0

                    // 拍1和3：和弦冲击（重）
                    if beatIdx % 2 == 0 { // 下拍 0,2,4...
                        let env = burstEnvelope(t: tInBeat, length: chordBurstSec)
                        if env > 0 {
                            // 叠加 C大三和弦 + 八度
                            let s1 = sin(twoPi * C5 * t)
                            let s2 = sin(twoPi * E5 * t)
                            let s3 = sin(twoPi * G5 * t)
                            let s4 = sin(twoPi * C6 * t)
                            // 归一化混合
                            sample += env * chordAmp * (s1 + s2 + s3 + s4) / 4.0
                        }
                    } else {
                        // 拍2和4：高音短促撞击（轻）
                        let env = burstEnvelope(t: tInBeat, length: pingBurstSec)
                        if env > 0 {
                            let s1 = sin(twoPi * C6 * t)
                            let s2 = sin(twoPi * G6 * t)
                            sample += env * pingAmp * (s1 + s2) / 2.0
                        }
                    }

                    // 防止削波
                    if sample > 1.0 { sample = 1.0 }
                    if sample < -1.0 { sample = -1.0 }

                    ch[frameIndex] = Float(sample)
                    frameIndex += 1
                }
            }

            try audioFile.write(from: buffer)
            print("✅ 已生成庆典铃声: \(outURL.lastPathComponent)")
        } catch {
            print("❌ 生成庆典铃声失败: \(error)")
        }
    }
}

