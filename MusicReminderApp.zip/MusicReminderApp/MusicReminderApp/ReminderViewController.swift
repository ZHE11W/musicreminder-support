import UIKit
import UserNotifications

// MARK: - 提醒状态枚举
enum ReminderStatus: String, Codable {
    case pending = "pending"        // 待触发
    case completed = "completed"    // 已完成（普通提醒触发后，或重要提醒被手动停止）
    case missed = "missed"         // 已错过（重要提醒响铃结束但未被停止）
}

// MARK: - 提醒数据模型
struct Reminder: Codable {
    let id: String
    let title: String
    let date: Date
    let hasTimeReminder: Bool
    let isImportant: Bool // 新增：是否为重要提醒
    var status: ReminderStatus // 新增：提醒状态

    // 编码键
    enum CodingKeys: String, CodingKey {
        case id
        case title
        case date
        case hasTimeReminder
        case isImportant
        case status
        case hasTriggered // 用于兼容旧数据
    }

    init(title: String, date: Date, hasTimeReminder: Bool = true, isImportant: Bool = false) {
        self.id = UUID().uuidString
        self.title = title
        self.date = date
        self.hasTimeReminder = hasTimeReminder
        self.isImportant = isImportant
        self.status = .pending // 初始为待触发
    }

    // 自定义解码器，处理旧数据兼容性
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        id = try container.decode(String.self, forKey: .id)
        title = try container.decode(String.self, forKey: .title)
        date = try container.decode(Date.self, forKey: .date)
        hasTimeReminder = try container.decode(Bool.self, forKey: .hasTimeReminder)

        // 如果旧数据没有isImportant字段，默认为false
        isImportant = try container.decodeIfPresent(Bool.self, forKey: .isImportant) ?? false

        // 处理旧数据的状态转换
        if let newStatus = try container.decodeIfPresent(ReminderStatus.self, forKey: .status) {
            status = newStatus
        } else {
            // 旧数据兼容：根据hasTriggered和时间判断状态
            let hasTriggered = try container.decodeIfPresent(Bool.self, forKey: .hasTriggered) ?? (date < Date())
            if hasTriggered {
                status = date < Date() ? .completed : .pending
            } else {
                status = .pending
            }
        }
    }

    // 自定义编码器
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)

        try container.encode(id, forKey: .id)
        try container.encode(title, forKey: .title)
        try container.encode(date, forKey: .date)
        try container.encode(hasTimeReminder, forKey: .hasTimeReminder)
        try container.encode(isImportant, forKey: .isImportant)
        try container.encode(status, forKey: .status)
        // 不编码hasTriggered，因为它只用于读取旧数据
    }
}

class ReminderViewController: UIViewController {
    
    // MARK: - UI 组件
    private let tableView = UITableView()
    private let addButton = UIButton(type: .system)
    private let emptyStateLabel = UILabel()
    
    // MARK: - 数据
    private var reminders: [Reminder] = []

    // MARK: - 停止音乐按钮
    private var stopMusicButton: UIButton?
    
    // MARK: - 生命周期
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        setupConstraints()

        // 在后台线程加载数据，避免阻塞主线程
        // 强制确保通知代理设置
        ensureNotificationDelegate()

        DispatchQueue.global(qos: .userInitiated).async {
            self.loadReminders()

            DispatchQueue.main.async {
                self.checkNotificationPermission()
            }
        }

        // 监听停止按钮显示/隐藏通知
        NotificationCenter.default.addObserver(self, selector: #selector(showStopButton), name: NSNotification.Name("ShowStopMusicButton"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(hideStopButton), name: NSNotification.Name("HideStopMusicButton"), object: nil)

        // 监听提醒状态变化通知
        NotificationCenter.default.addObserver(self, selector: #selector(handleReminderStatusChanged), name: NSNotification.Name("ReminderStatusChanged"), object: nil)
    }

    @objc private func showStopButton() {
        showStopMusicButton()
    }

    @objc private func hideStopButton() {
        hideStopMusicButton()
    }

    @objc private func handleReminderStatusChanged(_ notification: Notification) {
        guard let userInfo = notification.userInfo,
              let reminderID = userInfo["reminderID"] as? String,
              let statusString = userInfo["status"] as? String else { return }

        print("📱 收到提醒状态变化通知: \(reminderID) -> \(statusString)")

        // 转换状态
        let newStatus: ReminderStatus
        switch statusString {
        case "completed":
            newStatus = .completed
        case "missed":
            newStatus = .missed
        default:
            newStatus = .pending
        }

        // 🔥 关键修复：如果提醒被标记为完成，确保清理所有相关的定时器和管理器
        if newStatus == .completed {
            print("🛑 提醒被标记为完成，清理相关资源: \(reminderID)")
            AggressiveReminderManager.shared.cancelAggressiveReminder(id: reminderID)

            // 取消对应的系统通知
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [reminderID])
            UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [reminderID])
        }

        // 找到对应的提醒并更新状态
        if let index = reminders.firstIndex(where: { $0.id == reminderID }) {
            reminders[index].status = newStatus

            // 保存数据
            saveReminders()

            // 立即刷新表格显示
            DispatchQueue.main.async {
                self.tableView.reloadData()
                print("✅ 界面已刷新，提醒状态已更新: \(self.reminders[index].title) -> \(newStatus)")
            }
        }
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateEmptyState()

        // 每次显示时都确保代理设置
        ensureNotificationDelegate()

        // 调试：显示当前所有待发通知
        debugPendingNotifications()
    }

    // MARK: - 确保通知代理设置
    private func ensureNotificationDelegate() {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            UNUserNotificationCenter.current().delegate = appDelegate
            print("🔧 ReminderViewController中确保通知代理设置为AppDelegate")

            // 验证代理设置
            let center = UNUserNotificationCenter.current()
            print("🔧 代理验证: \(center.delegate != nil ? "✅成功" : "❌失败")")
            print("🔧 代理类型: \(String(describing: type(of: center.delegate)))")
        }
    }

    // MARK: - 调试待发通知
    private func debugPendingNotifications() {
        UNUserNotificationCenter.current().getPendingNotificationRequests { requests in
            DispatchQueue.main.async {
                print("🔍 当前待发通知数量: \(requests.count)")
                for request in requests {
                    print("🔍 通知: \(request.content.title) - ID: \(request.identifier)")
                    if let trigger = request.trigger as? UNCalendarNotificationTrigger {
                        print("🔍 触发时间: \(trigger.dateComponents)")
                    }
                }
            }
        }
    }

    // MARK: - 通知声音自动播放
    // 现在使用通知的自定义声音功能，无论前台后台都会自动播放30秒音乐

    // MARK: - 停止音乐按钮设置
    private func setupStopMusicButton() {
        stopMusicButton = UIButton(type: .system)
        stopMusicButton?.setTitle("🛑 停止", for: .normal)
        stopMusicButton?.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        stopMusicButton?.backgroundColor = UIColor.systemRed
        stopMusicButton?.setTitleColor(.white, for: .normal)
        stopMusicButton?.layer.cornerRadius = 25
        stopMusicButton?.translatesAutoresizingMaskIntoConstraints = false
        stopMusicButton?.addTarget(self, action: #selector(stopMusicButtonTapped), for: .touchUpInside)
        stopMusicButton?.isHidden = true // 初始隐藏

        if let button = stopMusicButton {
            view.addSubview(button)

            NSLayoutConstraint.activate([
                button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                button.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -100),
                button.widthAnchor.constraint(equalToConstant: 150),
                button.heightAnchor.constraint(equalToConstant: 50)
            ])
        }
    }

    @objc private func stopMusicButtonTapped() {
        print("🛑 用户点击停止音乐按钮")
        AlarmPlayer.shared.stopAlarm()
        hideStopMusicButton()
    }

    private func showStopMusicButton() {
        DispatchQueue.main.async {
            self.stopMusicButton?.isHidden = false
            UIView.animate(withDuration: 0.3) {
                self.stopMusicButton?.alpha = 1.0
            }
        }
    }

    private func hideStopMusicButton() {
        DispatchQueue.main.async {
            UIView.animate(withDuration: 0.3, animations: {
                self.stopMusicButton?.alpha = 0.0
            }) { _ in
                self.stopMusicButton?.isHidden = true
            }
        }
    }

    // MARK: - 简化版本
    // 使用系统通知声音 + AlarmPlayer播放30秒音乐的组合方案
    
    // MARK: - UI 设置
    private func setupUI() {
        title = "提醒"
        view.backgroundColor = .systemBackground
        
        // 设置导航栏 - 模仿苹果提醒事项
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.largeTitleDisplayMode = .always

        // 添加设置按钮
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "gearshape"),
            style: .plain,
            target: self,
            action: #selector(settingsButtonTapped)
        )

        // 创建停止音乐按钮（初始隐藏）
        setupStopMusicButton()
        
        // 设置表格视图
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .systemBackground
        tableView.separatorStyle = .singleLine
        tableView.register(ReminderTableViewCell.self, forCellReuseIdentifier: "ReminderCell")
        
        // 设置空状态标签
        emptyStateLabel.text = "暂无提醒\n点击下方按钮添加新提醒"
        emptyStateLabel.textAlignment = .center
        emptyStateLabel.textColor = .secondaryLabel
        emptyStateLabel.font = .systemFont(ofSize: 24)
        emptyStateLabel.numberOfLines = 0
        emptyStateLabel.isHidden = true
        
        // 设置添加按钮 - 模仿苹果样式
        addButton.setTitle("+ 新建提醒", for: .normal)
        addButton.setTitleColor(.systemBlue, for: .normal)
        addButton.titleLabel?.font = .systemFont(ofSize: 24, weight: .medium)
        addButton.backgroundColor = .systemGray6
        addButton.layer.cornerRadius = 12
        addButton.addTarget(self, action: #selector(addButtonTapped), for: .touchUpInside)
        
        // 添加到视图
        view.addSubview(tableView)
        view.addSubview(emptyStateLabel)
        view.addSubview(addButton)
        
        // 设置自动布局
        tableView.translatesAutoresizingMaskIntoConstraints = false
        emptyStateLabel.translatesAutoresizingMaskIntoConstraints = false
        addButton.translatesAutoresizingMaskIntoConstraints = false
    }
    
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            // 表格视图约束
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: addButton.topAnchor, constant: -16),
            
            // 空状态标签约束
            emptyStateLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyStateLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -50),
            emptyStateLabel.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 32),
            emptyStateLabel.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -32),
            
            // 添加按钮约束
            addButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            addButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            addButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            addButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    // MARK: - 空状态管理
    private func updateEmptyState() {
        emptyStateLabel.isHidden = !reminders.isEmpty
        tableView.isHidden = reminders.isEmpty
    }
    
    // MARK: - 通知权限检查
    private func checkNotificationPermission() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                print("🔔 当前通知权限状态: \(settings.authorizationStatus.rawValue)")
                print("🔔 关键警报权限: \(settings.criticalAlertSetting.rawValue)")
                print("🔔 声音权限: \(settings.soundSetting.rawValue)")

                switch settings.authorizationStatus {
                case .notDetermined:
                    print("🔔 权限未确定，请求权限")
                    self.requestNotificationPermission()
                case .denied:
                    print("🔔 权限被拒绝，显示设置提示")
                    self.showNotificationPermissionAlert()
                case .authorized, .provisional, .ephemeral:
                    print("✅ 通知权限已获取")
                @unknown default:
                    print("⚠️ 未知权限状态")
                    self.requestNotificationPermission()
                }
            }
        }
    }

    // MARK: - 请求通知权限
    private func requestNotificationPermission() {
        let center = UNUserNotificationCenter.current()

        // 请求普通通知权限（不包括关键警报，因为需要特殊授权）
        let options: UNAuthorizationOptions = [.alert, .sound]  // 🔥 移除badge权限

        center.requestAuthorization(options: options) { granted, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ 权限请求失败: \(error)")
                } else if granted {
                    print("✅ 通知权限已授予")
                } else {
                    print("❌ 用户拒绝了通知权限")
                    self.showNotificationPermissionAlert()
                }
            }
        }
    }
    
    private func showNotificationPermissionAlert() {
        let alert = UIAlertController(
            title: "需要通知权限",
            message: "为了及时提醒您，请在设置中开启通知权限",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "去设置", style: .default) { _ in
            if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsUrl)
            }
        })
        
        alert.addAction(UIAlertAction(title: "稍后", style: .cancel))
        
        present(alert, animated: true)
    }
    
    // MARK: - 按钮事件
    @objc private func addButtonTapped() {
        showAddReminderAlert()
    }

    @objc private func settingsButtonTapped() {
        showSettingsMenu()
    }
    
    // MARK: - 显示添加提醒弹窗
    private func showAddReminderAlert() {
        let alert = UIAlertController(title: "新建提醒", message: nil, preferredStyle: .alert)
        
        // 添加文本输入框
        alert.addTextField { textField in
            textField.placeholder = "输入提醒内容"
            textField.clearButtonMode = .whileEditing
            textField.font = UIFont.systemFont(ofSize: 20)
        }
        
        // 确定按钮
        let confirmAction = UIAlertAction(title: "确定", style: .default) { [weak self] _ in
            guard let textField = alert.textFields?.first,
                  let title = textField.text,
                  !title.trimmingCharacters(in: .whitespaces).isEmpty else {
                return
            }
            
            self?.showDateTimePicker(for: title)
        }
        
        // 取消按钮
        let cancelAction = UIAlertAction(title: "取消", style: .cancel)
        
        alert.addAction(cancelAction)
        alert.addAction(confirmAction)
        
        present(alert, animated: true)
    }

    // MARK: - 显示日期时间选择器
    private func showDateTimePicker(for title: String) {
        // 创建一个专门的视图控制器
        let datePickerVC = UIViewController()
        datePickerVC.modalPresentationStyle = .pageSheet
        datePickerVC.view.backgroundColor = .systemBackground

        // 创建导航栏
        let navBar = UINavigationBar()
        navBar.translatesAutoresizingMaskIntoConstraints = false

        let navItem = UINavigationItem(title: "设置提醒时间")
        let cancelButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(dismissDatePicker))
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(datePickerDone(_:)))

        navItem.leftBarButtonItem = cancelButton
        navItem.rightBarButtonItem = doneButton
        navBar.setItems([navItem], animated: false)

        // 创建分离的日期和时间选择器
        let dateLabel = UILabel()
        dateLabel.text = "选择日期"
        dateLabel.font = UIFont.systemFont(ofSize: 22, weight: .medium)
        dateLabel.translatesAutoresizingMaskIntoConstraints = false

        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels

        // 设置最小日期为今天
        let calendar = Calendar.current
        let today = Date()
        datePicker.minimumDate = calendar.startOfDay(for: today) // 今天的开始时间
        datePicker.maximumDate = calendar.date(byAdding: .year, value: 3, to: today)
        datePicker.locale = Locale(identifier: "zh_CN")
        datePicker.translatesAutoresizingMaskIntoConstraints = false

        let timeLabel = UILabel()
        timeLabel.text = "选择时间"
        timeLabel.font = UIFont.systemFont(ofSize: 22, weight: .medium)
        timeLabel.translatesAutoresizingMaskIntoConstraints = false

        let timePicker = UIDatePicker()
        timePicker.datePickerMode = .time
        timePicker.preferredDatePickerStyle = .wheels
        timePicker.locale = Locale(identifier: "zh_CN")
        timePicker.translatesAutoresizingMaskIntoConstraints = false

        // 设置默认时间为当前时间向上取整到下一个5分钟
        let nowComponents = calendar.dateComponents([.hour, .minute], from: today)
        let currentMinute = nowComponents.minute ?? 0
        let roundedMinute = ((currentMinute / 5) + 1) * 5 // 向上取整到下一个5分钟

        var defaultComponents = DateComponents()
        defaultComponents.hour = nowComponents.hour
        defaultComponents.minute = roundedMinute

        // 如果分钟超过55，进位到下一小时
        if roundedMinute >= 60 {
            defaultComponents.hour = (nowComponents.hour ?? 0) + 1
            defaultComponents.minute = 0
        }

        let defaultDateTime = calendar.date(from: defaultComponents) ?? calendar.date(byAdding: .minute, value: 5, to: today) ?? today
        datePicker.date = defaultDateTime

        // 设置时间选择器的最小时间为当前时间（因为默认选择今天）
        timePicker.minimumDate = today
        timePicker.date = defaultDateTime

        // 添加日期选择器的监听，当选择今天时限制时间
        datePicker.addTarget(self, action: #selector(datePickerChanged(_:)), for: .valueChanged)

        // 添加时间选择器的监听，防止选择过去时间
        timePicker.addTarget(self, action: #selector(timePickerChanged(_:)), for: .valueChanged)

        // 创建重要开关
        let importantLabel = UILabel()
        importantLabel.text = "重要提醒"
        importantLabel.font = UIFont.systemFont(ofSize: 22, weight: .medium)
        importantLabel.translatesAutoresizingMaskIntoConstraints = false

        let importantSwitch = UISwitch()
        importantSwitch.translatesAutoresizingMaskIntoConstraints = false

        // 删除重要提醒的说明文字，因为现在前台后台都能自动播放

        // 添加到视图
        datePickerVC.view.addSubview(navBar)
        datePickerVC.view.addSubview(dateLabel)
        datePickerVC.view.addSubview(datePicker)
        datePickerVC.view.addSubview(timeLabel)
        datePickerVC.view.addSubview(timePicker)
        datePickerVC.view.addSubview(importantLabel)
        datePickerVC.view.addSubview(importantSwitch)
        // importantDescLabel已删除

        // 设置约束
        NSLayoutConstraint.activate([
            navBar.topAnchor.constraint(equalTo: datePickerVC.view.safeAreaLayoutGuide.topAnchor),
            navBar.leadingAnchor.constraint(equalTo: datePickerVC.view.leadingAnchor),
            navBar.trailingAnchor.constraint(equalTo: datePickerVC.view.trailingAnchor),

            dateLabel.topAnchor.constraint(equalTo: navBar.bottomAnchor, constant: 20),
            dateLabel.leadingAnchor.constraint(equalTo: datePickerVC.view.leadingAnchor, constant: 20),

            datePicker.topAnchor.constraint(equalTo: dateLabel.bottomAnchor, constant: 10),
            datePicker.leadingAnchor.constraint(equalTo: datePickerVC.view.leadingAnchor),
            datePicker.trailingAnchor.constraint(equalTo: datePickerVC.view.trailingAnchor),
            datePicker.heightAnchor.constraint(equalToConstant: 120),

            timeLabel.topAnchor.constraint(equalTo: datePicker.bottomAnchor, constant: 20),
            timeLabel.leadingAnchor.constraint(equalTo: datePickerVC.view.leadingAnchor, constant: 20),

            timePicker.topAnchor.constraint(equalTo: timeLabel.bottomAnchor, constant: 10),
            timePicker.leadingAnchor.constraint(equalTo: datePickerVC.view.leadingAnchor),
            timePicker.trailingAnchor.constraint(equalTo: datePickerVC.view.trailingAnchor),
            timePicker.heightAnchor.constraint(equalToConstant: 120),

            // 重要开关约束
            importantLabel.topAnchor.constraint(equalTo: timePicker.bottomAnchor, constant: 30),
            importantLabel.leadingAnchor.constraint(equalTo: datePickerVC.view.leadingAnchor, constant: 20),

            importantSwitch.centerYAnchor.constraint(equalTo: importantLabel.centerYAnchor),
            importantSwitch.trailingAnchor.constraint(equalTo: datePickerVC.view.trailingAnchor, constant: -20)
        ])

        // 存储引用
        currentReminderTitle = title
        currentDatePicker = datePicker
        currentTimePicker = timePicker
        currentImportantSwitch = importantSwitch

        // 初始化时间约束
        updateTimePickerConstraints()

        present(datePickerVC, animated: true)
    }

    // 日期选择器变化时的处理
    @objc private func datePickerChanged(_ sender: UIDatePicker) {
        updateTimePickerConstraints()
    }

    // 时间选择器变化时的处理
    @objc private func timePickerChanged(_ sender: UIDatePicker) {
        validateSelectedDateTime()
    }

    // 验证选择的日期时间组合
    private func validateSelectedDateTime() {
        guard let datePicker = currentDatePicker,
              let timePicker = currentTimePicker else { return }

        let calendar = Calendar.current
        let selectedDate = datePicker.date
        let selectedTime = timePicker.date
        let now = Date()

        // 只有在选择今天的情况下才需要验证时间
        if calendar.isDate(selectedDate, inSameDayAs: now) {
            // 合并日期和时间来检查
            let dateComponents = calendar.dateComponents([.year, .month, .day], from: selectedDate)
            let timeComponents = calendar.dateComponents([.hour, .minute], from: selectedTime)

            var combinedComponents = DateComponents()
            combinedComponents.year = dateComponents.year
            combinedComponents.month = dateComponents.month
            combinedComponents.day = dateComponents.day
            combinedComponents.hour = timeComponents.hour
            combinedComponents.minute = timeComponents.minute

            if let combinedDate = calendar.date(from: combinedComponents) {
                // 只有当组合时间确实在过去时才调整（不给缓冲时间）
                if combinedDate <= now {
                    // 调整到当前时间的下一个5分钟
                    let nowComponents = calendar.dateComponents([.hour, .minute], from: now)
                    let currentMinute = nowComponents.minute ?? 0
                    let roundedMinute = ((currentMinute / 5) + 1) * 5

                    var adjustedComponents = DateComponents()
                    adjustedComponents.hour = nowComponents.hour
                    adjustedComponents.minute = roundedMinute

                    if roundedMinute >= 60 {
                        adjustedComponents.hour = (nowComponents.hour ?? 0) + 1
                        adjustedComponents.minute = 0
                    }

                    if let adjustedTime = calendar.date(from: adjustedComponents) {
                        timePicker.date = adjustedTime
                    }
                }
            }
        }
        // 如果选择的是未来日期，不需要任何调整
    }

    // 更新时间选择器的约束
    private func updateTimePickerConstraints() {
        guard let datePicker = currentDatePicker,
              let timePicker = currentTimePicker else { return }

        let calendar = Calendar.current
        let selectedDate = datePicker.date
        let now = Date()

        // 如果选择的是今天，限制时间为当前时间之后
        if calendar.isDate(selectedDate, inSameDayAs: now) {
            timePicker.minimumDate = now

            // 只有当前选择的时间确实早于现在时才调整
            if timePicker.date <= now { // 不给缓冲时间
                // 调整到当前时间的下一个5分钟，而不是1小时后
                let nowComponents = calendar.dateComponents([.hour, .minute], from: now)
                let currentMinute = nowComponents.minute ?? 0
                let roundedMinute = ((currentMinute / 5) + 1) * 5

                var adjustedComponents = DateComponents()
                adjustedComponents.hour = nowComponents.hour
                adjustedComponents.minute = roundedMinute

                if roundedMinute >= 60 {
                    adjustedComponents.hour = (nowComponents.hour ?? 0) + 1
                    adjustedComponents.minute = 0
                }

                if let adjustedTime = calendar.date(from: adjustedComponents) {
                    timePicker.date = adjustedTime
                }
            }
        } else {
            // 如果选择的是未来日期，移除时间限制（可以选择任意时间）
            timePicker.minimumDate = nil
        }
    }

    // 存储当前选择的提醒标题和日期选择器
    private var currentReminderTitle: String?
    private var currentDatePicker: UIDatePicker?
    private var currentTimePicker: UIDatePicker?
    private var currentImportantSwitch: UISwitch?

    @objc private func dismissDatePicker() {
        dismiss(animated: true)
        currentReminderTitle = nil
        currentDatePicker = nil
        currentTimePicker = nil
        currentImportantSwitch = nil
    }

    @objc private func datePickerDone(_ sender: UIBarButtonItem) {
        guard let title = currentReminderTitle,
              let datePicker = currentDatePicker,
              let timePicker = currentTimePicker,
              let importantSwitch = currentImportantSwitch else {
            dismiss(animated: true)
            return
        }

        // 合并日期和时间
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: datePicker.date)
        let timeComponents = calendar.dateComponents([.hour, .minute], from: timePicker.date)

        var finalComponents = DateComponents()
        finalComponents.year = dateComponents.year
        finalComponents.month = dateComponents.month
        finalComponents.day = dateComponents.day
        finalComponents.hour = timeComponents.hour
        finalComponents.minute = timeComponents.minute

        guard let finalDate = calendar.date(from: finalComponents) else {
            showErrorMessage("日期时间设置错误")
            return
        }

        // 检查选择的时间是否在未来
        let now = Date()
        if finalDate <= now { // 必须是未来时间
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "zh_CN")
            formatter.dateFormat = "yyyy年M月d日 HH:mm"

            showErrorMessage("提醒时间必须是未来的时间\n当前时间：\(formatter.string(from: now))\n您选择的时间：\(formatter.string(from: finalDate))")
            return
        }

        addReminder(title: title, date: finalDate, hasTimeReminder: true, isImportant: importantSwitch.isOn)
        dismiss(animated: true)
        currentReminderTitle = nil
        currentDatePicker = nil
        currentTimePicker = nil
        currentImportantSwitch = nil
    }

    // MARK: - 添加提醒
    private func addReminder(title: String, date: Date, hasTimeReminder: Bool, isImportant: Bool = false) {
        let reminder = Reminder(title: title, date: date, hasTimeReminder: hasTimeReminder, isImportant: isImportant)
        reminders.append(reminder)

        // 排序提醒（按时间）
        reminders.sort { $0.date < $1.date }

        // 刷新表格
        tableView.reloadData()
        updateEmptyState()

        // 安排通知
        if hasTimeReminder {
            scheduleNotification(for: reminder)
        }

        // 保存数据
        saveReminders()

        // 显示成功提示
        showSuccessMessage("提醒已设置")
    }

    // MARK: - 安排通知（使用NotificationManager）
    private func scheduleNotification(for reminder: Reminder) {
        // 使用NotificationManager来安排通知，确保正确区分重要和普通提醒
        NotificationManager.shared.scheduleReminder(
            id: reminder.id,
            title: reminder.title,
            body: reminder.title,
            date: reminder.date,
            isImportant: reminder.isImportant
        ) { success in
            DispatchQueue.main.async {
                if success {
                    let type = reminder.isImportant ? "🔥重要" : "📝普通"
                    print("✅ \(type)通知已安排: \(reminder.title)")

                    if reminder.isImportant {
                        print("🚨 重要提醒已设置，到时会自动播放铃声")
                        // 🔥 修复：禁用激进定时器，避免重复触发
                        // AggressiveReminderManager.shared.scheduleAggressiveReminder(
                        //     id: reminder.id,
                        //     title: reminder.title,
                        //     date: reminder.date
                        // )

                        // 🔥 移除备用提醒，避免提前触发问题
                        // self.scheduleBackupReminders(for: reminder)
                    } else {
                        print("📝 普通提醒已设置，到时只会显示通知")
                        // 普通提醒：设置定时器，时间到了立即标记为完成
                        self.scheduleNormalReminderCompletion(for: reminder)
                    }
                } else {
                    print("❌ 通知安排失败: \(reminder.title)")
                    self.showErrorMessage("通知安排失败，请检查时间设置")
                }
            }
        }
    }

    // MARK: - 设置备用提醒（提高可靠性）
    private func scheduleBackupReminders(for reminder: Reminder) {
        let backupTimes: [TimeInterval] = [-30, -10, 0, 10] // 提前30秒、提前10秒、准时、延后10秒

        for (index, offset) in backupTimes.enumerated() {
            let backupDate = reminder.date.addingTimeInterval(offset)
            guard backupDate > Date() else { continue }

            let backupId = "\(reminder.id)_backup_\(index)"

            NotificationManager.shared.scheduleReminder(
                id: backupId,
                title: reminder.title,
                body: reminder.title,
                date: backupDate,
                isImportant: true
            ) { success in
                if success {
                    print("✅ 备用提醒\(index)已设置: \(offset)秒偏移")
                }
            }
        }
    }

    // MARK: - 普通提醒自动完成
    private func scheduleNormalReminderCompletion(for reminder: Reminder) {
        let timeInterval = reminder.date.timeIntervalSinceNow

        print("⏰ 设置普通提醒自动完成，\(Int(timeInterval))秒后触发")

        if timeInterval <= 0 {
            // 时间已到，立即标记为完成
            print("✅ 普通提醒时间已到，立即标记为完成")
            markNormalReminderAsCompleted(reminderID: reminder.id)
            return
        }

        // 设置定时器，时间到了立即标记为完成
        Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: false) { [weak self] _ in
            print("⏰⏰⏰ 普通提醒定时器触发，立即标记为完成")
            self?.markNormalReminderAsCompleted(reminderID: reminder.id)
        }
    }

    // MARK: - 标记普通提醒为完成
    private func markNormalReminderAsCompleted(reminderID: String) {
        print("✅ 标记普通提醒为完成: \(reminderID)")

        // 找到对应的提醒并更新状态
        if let index = reminders.firstIndex(where: { $0.id == reminderID }) {
            reminders[index].status = .completed

            // 保存数据
            saveReminders()

            // 立即刷新表格显示
            DispatchQueue.main.async {
                self.tableView.reloadData()
                print("✅ 普通提醒界面已刷新: \(self.reminders[index].title) -> completed")
            }
        }
    }

    // MARK: - 创建通知声音
    private func createNotificationSound() -> UNNotificationSound {
        // 简化音频处理，直接使用系统默认声音
        print("🎵 使用系统默认通知声音")
        return UNNotificationSound.default
    }

    // MARK: - 创建增强的关键警报声音
    private func createEnhancedCriticalSound() -> UNNotificationSound {
        // 使用系统的关键警报，但我们可以在前台时增强它
        return UNNotificationSound.defaultCritical
    }

    // MARK: - 备用闹钟触发机制
    private func startBackupAlarmTrigger(for reminder: Reminder) {
        let timeInterval = reminder.date.timeIntervalSinceNow

        print("⏰ 启动备用闹钟触发机制，\(Int(timeInterval))秒后触发")

        // 如果时间已经过了，立即触发
        if timeInterval <= 0 {
            print("🔥 时间已到，立即触发备用闹钟")
            triggerBackupAlarm(for: reminder)
            return
        }

        // 使用定时器在指定时间触发
        Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: false) { [weak self] _ in
            print("⏰⏰⏰ 备用闹钟时间到！")
            self?.triggerBackupAlarm(for: reminder)
        }
    }

    // MARK: - 触发备用闹钟（已禁用，避免重复触发）
    private func triggerBackupAlarm(for reminder: Reminder) {
        // 🔥 修复：禁用备用闹钟，避免重复触发
        print("🔧 备用闹钟已禁用，只依赖系统通知触发")
    }

    // MARK: - 显示成功消息
    private func showSuccessMessage(_ message: String) {
        let alert = UIAlertController(title: "✅", message: message, preferredStyle: .alert)
        present(alert, animated: true)

        // 1秒后自动消失
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            alert.dismiss(animated: true)
        }
    }

    // MARK: - 显示错误消息
    private func showErrorMessage(_ message: String) {
        let alert = UIAlertController(title: "❌", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        present(alert, animated: true)
    }

    // MARK: - 数据持久化
    private func saveReminders() {
        DataManager.shared.saveReminders(reminders)
    }

    private func loadReminders() {
        // 使用DataManager加载数据
        let loadedReminders = DataManager.shared.loadReminders()

        DispatchQueue.main.async {
            self.reminders = loadedReminders
            // 排序提醒（按时间）
            self.reminders.sort { $0.date < $1.date }
            self.tableView.reloadData()
            self.updateEmptyState()
            print("✅ 提醒数据加载成功，共\(self.reminders.count)条")
        }
    }
}

// MARK: - UITableViewDataSource
extension ReminderViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reminders.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReminderCell", for: indexPath) as! ReminderTableViewCell
        let reminder = reminders[indexPath.row]
        cell.configure(with: reminder)
        return cell
    }
}

// MARK: - UITableViewDelegate
extension ReminderViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        let reminder = reminders[indexPath.row]
        showReminderDetail(reminder)
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let reminder = reminders[indexPath.row]

            // 取消通知
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [reminder.id])

            // 删除数据
            reminders.remove(at: indexPath.row)

            // 删除表格行
            tableView.deleteRows(at: [indexPath], with: .fade)

            // 更新空状态
            updateEmptyState()

            // 保存数据
            saveReminders()
        }
    }

    private func showReminderDetail(_ reminder: Reminder) {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy年M月d日 HH:mm"

        let message = "时间: \(formatter.string(from: reminder.date))"

        let alert = UIAlertController(title: reminder.title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "确定", style: .default))

        present(alert, animated: true)
    }

    // MARK: - 设置菜单
    private func showSettingsMenu() {
        let alert = UIAlertController(title: "设置", message: nil, preferredStyle: .actionSheet)

        // 查看待发送通知
        alert.addAction(UIAlertAction(title: "查看待发送通知", style: .default) { _ in
            self.showPendingNotifications()
        })

        // 通知权限设置
        alert.addAction(UIAlertAction(title: "通知权限设置", style: .default) { _ in
            NotificationManager.shared.showPermissionAlert(from: self)
        })

        // 调试信息已移除（DebugHelper已删除）

        alert.addAction(UIAlertAction(title: "取消", style: .cancel))

        // iPad支持
        if let popover = alert.popoverPresentationController {
            popover.barButtonItem = navigationItem.rightBarButtonItem
        }

        present(alert, animated: true)
    }

    // MARK: - 查看待发送通知
    private func showPendingNotifications() {
        NotificationManager.shared.getPendingNotifications { requests in
            let message = requests.isEmpty ? "暂无待发送的通知" : "共有 \(requests.count) 个待发送的通知"

            let alert = UIAlertController(title: "待发送通知", message: message, preferredStyle: .alert)

            if !requests.isEmpty {
                alert.addAction(UIAlertAction(title: "取消所有通知", style: .destructive) { _ in
                    NotificationManager.shared.cancelAllNotifications()
                    self.showSuccessMessage("已取消所有通知")
                })
            }

            alert.addAction(UIAlertAction(title: "确定", style: .default))
            self.present(alert, animated: true)
        }
    }
}

// MARK: - 提醒表格单元格
class ReminderTableViewCell: UITableViewCell {

    private let titleLabel = UILabel()
    private let timeLabel = UILabel()
    private let iconImageView = UIImageView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        // 设置图标
        iconImageView.image = UIImage(systemName: "bell.fill")
        iconImageView.tintColor = .systemBlue
        iconImageView.contentMode = .scaleAspectFit

        // 设置标题标签
        titleLabel.font = .systemFont(ofSize: 24, weight: .medium)
        titleLabel.textColor = .label
        titleLabel.numberOfLines = 2

        // 设置时间标签
        timeLabel.font = .systemFont(ofSize: 20, weight: .regular)
        timeLabel.textColor = .secondaryLabel

        // 添加到内容视图
        contentView.addSubview(iconImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(timeLabel)

        // 设置自动布局
        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        timeLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            // 图标约束
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            iconImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 24),
            iconImageView.heightAnchor.constraint(equalToConstant: 24),

            // 标题约束
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 12),
            titleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 16),

            // 时间约束
            timeLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            timeLabel.trailingAnchor.constraint(equalTo: titleLabel.trailingAnchor),
            timeLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 8),
            timeLabel.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -16)
        ])
    }

    func configure(with reminder: Reminder) {
        // 设置标题，根据状态和类型添加不同图标
        var titleText = reminder.title

        switch reminder.status {
        case .completed:
            // 已完成的提醒（普通提醒触发后，或重要提醒被手动停止）
            titleText = "✅ \(reminder.title)"
        case .missed:
            // 已错过的提醒（重要提醒响铃结束但未被停止）
            titleText = "❌ \(reminder.title)"
        case .pending:
            // 待触发的提醒
            if reminder.isImportant {
                titleText = "🔥 \(reminder.title)"
            } else {
                titleText = reminder.title
            }
        }

        titleLabel.text = titleText

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy年M月d日 HH:mm"
        timeLabel.text = formatter.string(from: reminder.date)

        // 根据状态设置颜色
        switch reminder.status {
        case .completed:
            // 已完成：灰色
            titleLabel.textColor = .secondaryLabel
            timeLabel.textColor = .tertiaryLabel
            iconImageView.tintColor = .systemGreen

        case .missed:
            // 已错过：红色
            titleLabel.textColor = .label
            timeLabel.textColor = .systemRed
            iconImageView.tintColor = .systemRed

        case .pending:
            // 待触发：根据类型设置颜色
            titleLabel.textColor = .label
            if reminder.isImportant {
                // 重要提醒：橙色
                timeLabel.textColor = .systemOrange
                iconImageView.tintColor = .systemOrange
            } else {
                // 普通提醒：蓝色
                timeLabel.textColor = .secondaryLabel
                iconImageView.tintColor = .systemBlue
            }
        }
    }
}
