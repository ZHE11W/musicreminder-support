import UIKit
import UserNotifications
import AVFoundation
import BackgroundTasks
import AudioToolbox

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    // 记录App运行状态
    private var appWasRunningInBackground = false
    private var lastActiveTime: Date?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        print("🚀 App启动")

        // 记录启动时间
        lastActiveTime = Date()

        // 🔥 清除应用角标
        UIApplication.shared.applicationIconBadgeNumber = 0

        // 检查是否从通知启动
        if launchOptions?[.remoteNotification] != nil || launchOptions?[.localNotification] != nil {
            print("📱 从通知启动App")
        }

        // 🔥 关键修复：立即设置通知代理
        UNUserNotificationCenter.current().delegate = self
        print("🔧 AppDelegate启动时设置通知代理")

        // 🔔 请求通知权限
        NotificationManager.shared.requestNotificationPermission { granted in
            if granted {
                print("✅ 通知权限已获取")
            } else {
                print("❌ 通知权限被拒绝")
            }
        }

        // 设置通知类别和操作
        setupNotificationCategories()

        // 🎵 配置音频会话
        configureAudioSession()


        // 🔔 初始化闹钟播放器
        _ = AlarmPlayer.shared

        // 清理所有旧的通知
        clearOldNotifications()

        // 📱 注册后台任务
        registerBackgroundTasks()

        // 🔄 数据迁移
        DataManager.shared.migrateDataIfNeeded()

        // 🔥 启用后台音频保持：用于在后台准点由App内播放器响铃
        BackgroundAudioManager.shared.startBackgroundAudioKeepAlive()
        print("✅ 已启用启动时的后台音频管理器")

        return true
    }

    // MARK: - 清理旧通知
    private func clearOldNotifications() {
        UNUserNotificationCenter.current().removeAllDeliveredNotifications()
        print("✅ 已清理所有旧通知")
    }

    // MARK: - 设置通知类别
    private func setupNotificationCategories() {
        // 重要提醒的操作
        let stopAction = UNNotificationAction(
            identifier: "STOP_IMPORTANT_REMINDER",
            title: "停止提醒",
            options: [.destructive]
        )

        let snoozeAction = UNNotificationAction(
            identifier: "SNOOZE_REMINDER",
            title: "稍后提醒",
            options: []
        )

        // 重要提醒类别
        let importantCategory = UNNotificationCategory(
            identifier: "IMPORTANT_REMINDER",
            actions: [stopAction, snoozeAction],
            intentIdentifiers: [],
            options: [.customDismissAction]
        )

        // 普通提醒类别
        let normalCategory = UNNotificationCategory(
            identifier: "NORMAL_REMINDER",
            actions: [],
            intentIdentifiers: [],
            options: []
        )

        // 注册类别
        UNUserNotificationCenter.current().setNotificationCategories([importantCategory, normalCategory])

        // 🔥 修复：不重复设置代理，启动时已设置
        print("🔧 通知代理已在启动时设置，不重复设置")
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
    }

    // MARK: - 后台任务注册
    private func registerBackgroundTasks() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: "com.musicreminder.refresh", using: nil) { task in
            self.handleBackgroundRefresh(task: task as! BGAppRefreshTask)
        }
    }

    // MARK: - 处理后台刷新
    private func handleBackgroundRefresh(task: BGAppRefreshTask) {
        print("🔄🔄🔄 后台刷新任务执行！")

        // 安排下一次后台刷新
        scheduleBackgroundRefresh()

        task.expirationHandler = {
            print("⏰ 后台任务即将过期")
            task.setTaskCompleted(success: false)
        }

        // 检查即将到期的重要提醒
        DispatchQueue.global().async {
            self.checkAndTriggerImportantReminders { success in
                print("🔄 后台任务完成，结果: \(success)")
                task.setTaskCompleted(success: success)
            }
        }
    }

    // MARK: - 检查并触发重要提醒（已禁用，避免重复触发）
    private func checkAndTriggerImportantReminders(completion: @escaping (Bool) -> Void) {
        // 🔥 修复：禁用重复检查逻辑，只依赖系统通知
        print("🔧 已禁用重复检查逻辑，只依赖系统通知触发")
        completion(false)
    }

    // MARK: - 安排后台刷新
    private func scheduleBackgroundRefresh() {
        let request = BGAppRefreshTaskRequest(identifier: "com.musicreminder.refresh")
        request.earliestBeginDate = Date(timeIntervalSinceNow: 30) // 30秒后就开始检查

        do {
            try BGTaskScheduler.shared.submit(request)
            print("✅ 后台刷新任务已安排（30秒后执行）")
        } catch {
            print("❌ 后台任务安排失败: \(error)")
        }
    }
    
    // MARK: - 音频会话配置（修复版）
    private func configureAudioSession() {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            // 🔥 修复：使用正确的配置，不使用.mixWithOthers防止音量键中断
            try audioSession.setCategory(.playback, mode: .default, options: [])
            print("✅ 音频会话配置成功（防止音量键中断Critical Alert）")
        } catch {
            print("❌ 音频会话配置失败: \(error)")
        }
    }

    // MARK: - 应用生命周期
    func applicationDidEnterBackground(_ application: UIApplication) {
        print("📱 应用进入后台")

        // 🔥 修复：不重复配置音频会话，使用统一配置
        print("🔧 使用统一的音频会话配置，不重复设置")

        // 应用进入后台时安排后台刷新
        scheduleBackgroundRefresh()

        // 🔥 启用后台音频保持，确保到点能由App内播放器连续响铃
        BackgroundAudioManager.shared.startBackgroundAudioKeepAlive()
        print("✅ 后台音频管理器已启用，确保后台连续响铃")

        // 🔥 修复：不重复设置通知代理
        // UNUserNotificationCenter.current().delegate = self

        // 记录进入后台的时间
        lastActiveTime = Date()
        print("📱 记录进入后台时间")
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // 应用即将进入前台时更新badge
        UIApplication.shared.applicationIconBadgeNumber = 0

        // 🔥 关键修复：检查是否有音乐正在播放，如果没有则不触发检查
        if !AlarmPlayer.shared.isPlaying() {
            print("📱 App即将进入前台，但没有音乐播放，跳过检查")
        } else {
            print("📱 App即将进入前台，音乐正在播放")
        }

        print("📱 App即将进入前台")
    }
}

// MARK: - UNUserNotificationCenterDelegate
extension AppDelegate: UNUserNotificationCenterDelegate {

    // 处理通知点击（含自定义操作）
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("🔔 用户点击了通知: \(response.notification.request.content.title)")

        let userInfo = response.notification.request.content.userInfo
        let action = response.actionIdentifier

        // 优先处理自定义操作按钮
        if action == "STOP_IMPORTANT_REMINDER" {
            print("🛑 用户点击了停止提醒按钮")
            AlarmPlayer.shared.stopAlarm()
            if let reminderID = userInfo["id"] as? String {
                cancelAllRelatedNotifications(reminderID: reminderID)
                markReminderAsCompleted(reminderID: reminderID)
            }
            completionHandler()
            return
        } else if action == "SNOOZE_REMINDER" {
            print("⏰ 用户点击了稍后提醒按钮")
            AlarmPlayer.shared.stopAlarm()
            if let title = userInfo["title"] as? String, let body = userInfo["body"] as? String {
                NotificationManager.shared.scheduleDelayedReminder(title: title, body: body, delayMinutes: 5)
            }
            if let reminderID = userInfo["id"] as? String {
                cancelAllRelatedNotifications(reminderID: reminderID)
            }
            completionHandler()
            return
        }

        // 默认处理：点击横幅
        if let type = userInfo["type"] as? String {
            switch type {
            case "reminder":
                print("🛑 用户点击通知，停止响铃并取消所有相关通知（默认处理）")
                AlarmPlayer.shared.stopAlarm()
                if let reminderID = userInfo["id"] as? String {
                    cancelAllRelatedNotifications(reminderID: reminderID)
                    markReminderAsCompleted(reminderID: reminderID)
                }
            case "delayed_reminder":
                if let reminderID = userInfo["id"] as? String {
                    markReminderAsCompleted(reminderID: reminderID)
                }
            default:
                break
            }
        }

        completionHandler()
    }

    // 前台收到通知时的处理
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("🔔 收到通知（前台）: \(notification.request.content.title)")
        print("🔔 通知ID: \(notification.request.identifier)")

        // 根据通知ID决定是否播放声音：
        // - 主30秒与第二个30秒（含 _second_alarm）需要声音
        // - 每2秒的重复弹窗（含 _repeat_）不播放声音，避免与主铃声重叠
        let identifier = notification.request.identifier
        let userInfo = notification.request.content.userInfo
        let isRepeat = identifier.contains("_repeat_")

        if let type = userInfo["type"] as? String, type == "reminder" {
            if isRepeat {
                print("🔕 前台展示重复弹窗（无声）: \(identifier)")
                completionHandler([.banner])
            } else {
                print("🔕 前台展示主/次提醒（无声，App内播音）: \(identifier)")
                // 前台到点，直接由App内播放器响铃，避免系统声音被硬件键静音
                let reminderID = userInfo["id"] as? String ?? "unknown"
                let title = userInfo["title"] as? String ?? "重要提醒"
                AlarmPlayer.shared.playImportantAlarm(for: reminderID, title: title)
                completionHandler([.banner])
            }
        } else {
            // 其它类型统一无声展示
            completionHandler([.banner])
        }
    }

    // 简化版本：不需要复杂的重复通知管理

    // MARK: - 应用生命周期
    func applicationDidBecomeActive(_ application: UIApplication) {
        // 🔥 清除应用角标
        UIApplication.shared.applicationIconBadgeNumber = 0

        // 🔥 简化：Critical Alert会自动播放，无需额外检查
        print("🔧 应用激活，Critical Alert会自动处理后台响铃")

        // 验证代理设置
        let center = UNUserNotificationCenter.current()
        print("🔧 代理验证: \(center.delegate != nil ? "✅成功" : "❌失败")")

        // 标记App正在运行
        appWasRunningInBackground = true
        lastActiveTime = Date()
        print("✅ App已激活，标记为运行状态")
    }

    // 删除重复的方法，使用原有的方法

    // MARK: - 检测App是否从被杀死状态启动
    private func wasAppKilledRecently() -> Bool {
        print("🔍🔍🔍 开始检测App状态")
        print("🔍 appWasRunningInBackground: \(appWasRunningInBackground)")
        print("🔍 lastActiveTime: \(lastActiveTime?.description ?? "nil")")

        // 如果App从未在后台运行过，说明是冷启动
        if !appWasRunningInBackground {
            print("🔍 检测结果：App冷启动（从未在后台运行）")
            return true
        }

        // 如果距离上次活跃时间超过2分钟，可能被杀死了
        if let lastTime = lastActiveTime {
            let timeSinceLastActive = Date().timeIntervalSince(lastTime)
            print("🔍 距离上次活跃: \(Int(timeSinceLastActive))秒")
            if timeSinceLastActive > 120 {
                print("🔍 检测结果：App可能被杀死（距离上次活跃\(Int(timeSinceLastActive))秒）")
                return true
            }
        }

        print("🔍 检测结果：App在后台运行")
        return false
    }

    // MARK: - 公开方法供其他类调用
    func isAppKilledRecently() -> Bool {
        return wasAppKilledRecently()
    }



    func applicationWillTerminate(_ application: UIApplication) {
        print("💀 应用即将终止")
        AggressiveReminderManager.shared.cleanup()
        BackgroundAudioManager.shared.stopBackgroundAudio()
    }

    // MARK: - 强制播放重要提醒（简化版）
    private func forcePlayImportantAlarm(reminderID: String, title: String) {
        print("🚨 强制播放重要提醒: \(title)")

        // 🔥 修复：简化逻辑，避免重复配置
        // 1. 立即播放系统声音（最可靠的方式）
        AudioServicesPlaySystemSound(1005)
        print("🔊 播放系统警报声")

        // 2. 启动AlarmPlayer（统一处理）
        DispatchQueue.main.async {
            AlarmPlayer.shared.playImportantAlarm(for: reminderID, title: title)
        }

        // 4. 设置重复播放系统声音，确保持续响铃
        self.startRepeatingSystemSound()
    }

    // MARK: - 重复播放系统声音
    private func startRepeatingSystemSound() {
        // 每3秒播放一次系统声音，持续1分钟
        var playCount = 0
        let maxPlays = 20 // 1分钟内播放20次

        Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { timer in
            playCount += 1

            if playCount <= maxPlays {
                AudioServicesPlaySystemSound(1005)
                print("🔊 重复播放系统声音 \(playCount)/\(maxPlays)")
            } else {
                timer.invalidate()
                print("⏰ 系统声音播放结束")
            }
        }
    }

    // MARK: - 标记普通提醒为已完成
    private func markReminderAsCompleted(reminderID: String) {
        print("✅ 标记普通提醒为已完成: \(reminderID)")

        // 通知主界面更新提醒状态
        NotificationCenter.default.post(
            name: NSNotification.Name("ReminderStatusChanged"),
            object: nil,
            userInfo: ["reminderID": reminderID, "status": "completed"]
        )
    }

    // MARK: - 标记重要提醒为已错过
    private func markReminderAsMissed(reminderID: String) {
        print("❌ 标记重要提醒为已错过: \(reminderID)")

        // 通知主界面更新提醒状态
        NotificationCenter.default.post(
            name: NSNotification.Name("ReminderStatusChanged"),
            object: nil,
            userInfo: ["reminderID": reminderID, "status": "missed"]
        )
    }

    // MARK: - 取消相关通知
    private func cancelAllRelatedNotifications(reminderID: String) {
        print("🗑️ 取消提醒ID \(reminderID) 的所有相关通知")

        // 1) 直接按已知ID集合清理（主 + 第二段 + 30个循环）
        var notificationIDs = [reminderID, "\(reminderID)_second_alarm"]
        for i in 1...30 { notificationIDs.append("\(reminderID)_repeat_\(i)") }
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: notificationIDs)
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: notificationIDs)

        // 2) 兜底：前缀匹配清理所有以 reminderID 开头的通知，避免历史版本残留ID规则导致漏网
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { requests in
            let extraPending = requests.map { $0.identifier }.filter { $0.hasPrefix(reminderID) }
            if !extraPending.isEmpty {
                center.removePendingNotificationRequests(withIdentifiers: extraPending)
                print("🧹 兜底清理待发送通知: \(extraPending.count) 条")
            }
        }
        center.getDeliveredNotifications { notis in
            let extraDelivered = notis.map { $0.request.identifier }.filter { $0.hasPrefix(reminderID) }
            if !extraDelivered.isEmpty {
                center.removeDeliveredNotifications(withIdentifiers: extraDelivered)
                print("🧹 兜底清理已送达通知: \(extraDelivered.count) 条")
            }
        }

        print("✅ 已取消相关通知（含兜底前缀清理）")
    }
}
