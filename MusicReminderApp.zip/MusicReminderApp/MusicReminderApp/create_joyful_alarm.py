#!/usr/bin/env python3
"""
创建喜悦欢快的闹钟铃声，类似欢快的小调
"""

import numpy as np
import wave

def create_joyful_alarm():
    # iOS规范参数
    sample_rate = 22050  # 22.05kHz
    duration = 30  # 30秒
    
    # 创建时间轴
    t = np.linspace(0, duration, int(sample_rate * duration), False)
    
    # 创建欢快的旋律（C大调音阶，类似欢快的儿歌）
    audio = np.zeros_like(t)
    
    # 欢快的音符序列（Do Re Mi Fa Sol La Ti Do）
    notes = [
        261.63,  # C4 (Do)
        293.66,  # D4 (Re)
        329.63,  # E4 (Mi)
        349.23,  # F4 (Fa)
        392.00,  # G4 (Sol)
        440.00,  # A4 (La)
        493.88,  # B4 (Ti)
        523.25,  # C5 (Do)
    ]
    
    # 创建欢快的旋律模式
    melody_pattern = [0, 2, 4, 2, 0, 4, 2, 0]  # Do Mi Sol Mi Do Sol Re Do
    note_duration = 0.5  # 每个音符0.5秒
    pause_duration = 0.1  # 音符间隔0.1秒
    
    current_time = 0
    pattern_index = 0
    
    for i, time in enumerate(t):
        # 计算当前应该播放哪个音符
        cycle_time = time % (len(melody_pattern) * (note_duration + pause_duration))
        note_index = int(cycle_time / (note_duration + pause_duration))
        within_note_time = cycle_time % (note_duration + pause_duration)
        
        if within_note_time < note_duration and note_index < len(melody_pattern):
            # 在音符播放时间内
            freq = notes[melody_pattern[note_index]]
            
            # 添加和声（三度和五度）
            harmony1 = notes[min(melody_pattern[note_index] + 2, len(notes) - 1)]  # 三度
            harmony2 = notes[min(melody_pattern[note_index] + 4, len(notes) - 1)]  # 五度
            
            # 基础音量
            amplitude = 0.15
            
            # 添加音符内的渐强渐弱
            note_progress = within_note_time / note_duration
            if note_progress < 0.1:
                amplitude *= note_progress / 0.1  # 渐强
            elif note_progress > 0.8:
                amplitude *= (1 - note_progress) / 0.2  # 渐弱
            
            # 生成主旋律 + 和声
            main_tone = amplitude * np.sin(2 * np.pi * freq * time)
            harmony_tone1 = amplitude * 0.3 * np.sin(2 * np.pi * harmony1 * time)
            harmony_tone2 = amplitude * 0.2 * np.sin(2 * np.pi * harmony2 * time)
            
            audio[i] = main_tone + harmony_tone1 + harmony_tone2
            
            # 添加轻微的颤音让声音更生动
            vibrato = 1 + 0.03 * np.sin(2 * np.pi * 5 * time)  # 5Hz颤音
            audio[i] *= vibrato
    
    # 添加整体的动态变化
    envelope = np.ones_like(audio)
    fade_time = int(sample_rate * 1.0)  # 1秒淡入淡出
    
    # 淡入
    envelope[:fade_time] = np.linspace(0, 1, fade_time)
    # 淡出
    envelope[-fade_time:] = np.linspace(1, 0, fade_time)
    
    # 添加整体的节奏感（轻微的音量波动）
    rhythm = 1 + 0.1 * np.sin(2 * np.pi * 2 * t)  # 2Hz的节奏波动
    
    audio *= envelope * rhythm
    
    # 转换为16位整数
    audio_int = (audio * 32767).astype(np.int16)
    
    # 保存为WAV文件
    with wave.open('MusicReminderApp/joyful_alarm.wav', 'w') as wav_file:
        wav_file.setnchannels(1)  # 单声道
        wav_file.setsampwidth(2)  # 16位
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(audio_int.tobytes())
    
    file_size = len(audio_int.tobytes()) / 1024  # KB
    print(f"✅ 创建了喜悦欢快的闹钟铃声: joyful_alarm.wav")
    print(f"📊 文件大小: {file_size:.1f} KB")
    print(f"⏱️ 时长: {duration} 秒")
    print(f"🎵 特点: Do-Re-Mi旋律 + 三度五度和声 + 轻微颤音 + 节奏感")
    print(f"😊 风格: 欢快喜悦，类似儿歌旋律")
    print(f"🔊 采样率: {sample_rate} Hz")

if __name__ == "__main__":
    create_joyful_alarm()
