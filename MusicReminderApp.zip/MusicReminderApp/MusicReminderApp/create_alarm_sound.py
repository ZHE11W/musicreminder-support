#!/usr/bin/env python3
"""
创建一个60秒的持续响铃音频文件
这个文件将被用作iOS通知的自定义声音，实现真正的后台自动持续响铃
"""

import numpy as np
import wave
import os

def create_alarm_sound():
    # 音频参数
    sample_rate = 44100  # 44.1kHz
    duration = 60  # 60秒持续响铃
    frequency = 800  # 800Hz 响铃频率
    
    # 计算总样本数
    total_samples = int(sample_rate * duration)
    
    # 生成时间轴
    t = np.linspace(0, duration, total_samples, False)
    
    # 创建间歇性响铃模式：0.5秒响，0.3秒停，循环
    cycle_duration = 0.8  # 每个周期0.8秒
    beep_duration = 0.5   # 响铃0.5秒
    
    # 生成音频波形
    audio = np.zeros(total_samples)
    
    for i, time in enumerate(t):
        cycle_time = time % cycle_duration
        if cycle_time < beep_duration:
            # 响铃阶段：生成正弦波
            amplitude = 0.8
            audio[i] = amplitude * np.sin(2 * np.pi * frequency * time)
        else:
            # 静音阶段
            audio[i] = 0.0
    
    # 转换为16位整数
    audio_int16 = (audio * 32767).astype(np.int16)
    
    # 保存为WAV文件
    output_file = "alarm_sound.wav"
    with wave.open(output_file, 'w') as wav_file:
        wav_file.setnchannels(1)  # 单声道
        wav_file.setsampwidth(2)  # 16位
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(audio_int16.tobytes())
    
    print(f"✅ 创建了60秒持续响铃音频文件: {output_file}")
    print(f"📊 文件大小: {os.path.getsize(output_file) / 1024:.1f} KB")
    print("🔊 这个文件将实现真正的后台自动持续响铃")

if __name__ == "__main__":
    create_alarm_sound()
