import UIKit

// MARK: - 记录数据模型
struct Record: Codable {
    let id: String
    let title: String
    let content: String
    let date: Date
    let type: RecordType

    enum RecordType: Codable {
        case text
        case voice // 暂时禁用
    }

    init(title: String, content: String, type: RecordType = .text) {
        self.id = UUID().uuidString
        self.title = title
        self.content = content
        self.date = Date()
        self.type = type
    }

    // 用于更新记录的初始化方法
    init(id: String, title: String, content: String, date: Date, type: RecordType) {
        self.id = id
        self.title = title
        self.content = content
        self.date = date
        self.type = type
    }
}

class RecordViewController: UIViewController {
    
    // MARK: - UI 组件
    private let tableView = UITableView()
    private let addButton = UIButton(type: .system)
    private let emptyStateLabel = UILabel()
    
    // MARK: - 数据
    private var records: [Record] = []
    private var allRecords: [Record] = [] // 保存所有记录
    private var isSearching = false // 搜索状态

    // 用于新建记录的临时引用
    private var currentTitleTextField: UITextField?
    private var currentContentTextView: UITextView?
    private var currentPlaceholderLabel: UILabel?

    // 用于编辑记录的临时引用
    private var currentEditingRecord: Record?
    
    // MARK: - 生命周期
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
        setupConstraints()

        // 在后台线程加载数据，避免阻塞主线程
        DispatchQueue.global(qos: .userInitiated).async {
            self.loadRecords()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateEmptyState()
    }
    
    // MARK: - UI 设置
    private func setupUI() {
        title = "记录"
        view.backgroundColor = .systemBackground

        // 设置导航栏 - 模仿苹果提醒事项
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.largeTitleDisplayMode = .always

        // 初始化导航栏
        updateNavigationBar()
        
        // 设置表格视图
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .systemBackground
        tableView.separatorStyle = .singleLine
        tableView.register(RecordTableViewCell.self, forCellReuseIdentifier: "RecordCell")
        
        // 设置空状态标签
        emptyStateLabel.text = "暂无记录\n点击下方按钮添加新记录"
        emptyStateLabel.textAlignment = .center
        emptyStateLabel.textColor = .secondaryLabel
        emptyStateLabel.font = .systemFont(ofSize: 24)
        emptyStateLabel.numberOfLines = 0
        emptyStateLabel.isHidden = true
        
        // 设置添加按钮 - 模仿苹果样式
        addButton.setTitle("+ 新建记录", for: .normal)
        addButton.setTitleColor(.systemBlue, for: .normal)
        addButton.titleLabel?.font = .systemFont(ofSize: 24, weight: .medium)
        addButton.backgroundColor = .systemGray6
        addButton.layer.cornerRadius = 12
        addButton.addTarget(self, action: #selector(addButtonTapped), for: .touchUpInside)
        
        // 添加到视图
        view.addSubview(tableView)
        view.addSubview(emptyStateLabel)
        view.addSubview(addButton)
        
        // 设置自动布局
        tableView.translatesAutoresizingMaskIntoConstraints = false
        emptyStateLabel.translatesAutoresizingMaskIntoConstraints = false
        addButton.translatesAutoresizingMaskIntoConstraints = false
    }
    
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            // 表格视图约束
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: addButton.topAnchor, constant: -16),
            
            // 空状态标签约束
            emptyStateLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            emptyStateLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -50),
            emptyStateLabel.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 32),
            emptyStateLabel.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -32),
            
            // 添加按钮约束
            addButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            addButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            addButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16),
            addButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    // MARK: - 空状态管理
    private func updateEmptyState() {
        emptyStateLabel.isHidden = !records.isEmpty
        tableView.isHidden = records.isEmpty
    }
    
    // MARK: - 按钮事件
    @objc private func addButtonTapped() {
        showAddRecordAlert()
    }

    @objc private func searchButtonTapped() {
        showSearchAlert()
    }
    
    // MARK: - 显示添加记录弹窗
    private func showAddRecordAlert() {
        let addRecordVC = UIViewController()
        addRecordVC.modalPresentationStyle = .pageSheet
        addRecordVC.view.backgroundColor = .systemBackground

        // 创建导航栏
        let navBar = UINavigationBar()
        navBar.translatesAutoresizingMaskIntoConstraints = false

        let navItem = UINavigationItem(title: "新建记录")
        let cancelButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(dismissAddRecord))
        let saveButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveNewRecord))

        navItem.leftBarButtonItem = cancelButton
        navItem.rightBarButtonItem = saveButton
        navBar.setItems([navItem], animated: false)

        // 创建标题输入框（单行）
        let titleTextField = UITextField()
        titleTextField.placeholder = "输入记录标题"
        titleTextField.borderStyle = .roundedRect
        titleTextField.font = UIFont.systemFont(ofSize: 20)
        titleTextField.translatesAutoresizingMaskIntoConstraints = false

        // 创建内容输入框（多行）
        let contentTextView = UITextView()
        contentTextView.font = UIFont.systemFont(ofSize: 20)
        contentTextView.layer.borderColor = UIColor.systemGray4.cgColor
        contentTextView.layer.borderWidth = 1
        contentTextView.layer.cornerRadius = 8
        contentTextView.translatesAutoresizingMaskIntoConstraints = false

        // 添加占位符
        let placeholderLabel = UILabel()
        placeholderLabel.text = "输入记录内容..."
        placeholderLabel.font = UIFont.systemFont(ofSize: 20)
        placeholderLabel.textColor = .placeholderText
        placeholderLabel.translatesAutoresizingMaskIntoConstraints = false
        contentTextView.addSubview(placeholderLabel)

        // 添加到视图
        addRecordVC.view.addSubview(navBar)
        addRecordVC.view.addSubview(titleTextField)
        addRecordVC.view.addSubview(contentTextView)

        // 设置约束
        NSLayoutConstraint.activate([
            navBar.topAnchor.constraint(equalTo: addRecordVC.view.safeAreaLayoutGuide.topAnchor),
            navBar.leadingAnchor.constraint(equalTo: addRecordVC.view.leadingAnchor),
            navBar.trailingAnchor.constraint(equalTo: addRecordVC.view.trailingAnchor),

            titleTextField.topAnchor.constraint(equalTo: navBar.bottomAnchor, constant: 20),
            titleTextField.leadingAnchor.constraint(equalTo: addRecordVC.view.leadingAnchor, constant: 16),
            titleTextField.trailingAnchor.constraint(equalTo: addRecordVC.view.trailingAnchor, constant: -16),
            titleTextField.heightAnchor.constraint(equalToConstant: 44),

            contentTextView.topAnchor.constraint(equalTo: titleTextField.bottomAnchor, constant: 16),
            contentTextView.leadingAnchor.constraint(equalTo: addRecordVC.view.leadingAnchor, constant: 16),
            contentTextView.trailingAnchor.constraint(equalTo: addRecordVC.view.trailingAnchor, constant: -16),
            // 设置适中的高度，不要占满整个屏幕
            contentTextView.heightAnchor.constraint(equalToConstant: 200),

            placeholderLabel.topAnchor.constraint(equalTo: contentTextView.topAnchor, constant: 8),
            placeholderLabel.leadingAnchor.constraint(equalTo: contentTextView.leadingAnchor, constant: 5)
        ])

        // 存储引用以便在保存时使用
        currentTitleTextField = titleTextField
        currentContentTextView = contentTextView
        currentPlaceholderLabel = placeholderLabel

        // 设置文本变化监听
        contentTextView.delegate = self

        present(addRecordVC, animated: true) {
            titleTextField.becomeFirstResponder()
        }
    }

    // 新建记录相关方法
    @objc private func dismissAddRecord() {
        dismiss(animated: true)
        currentTitleTextField = nil
        currentContentTextView = nil
        currentPlaceholderLabel = nil
    }

    @objc private func saveNewRecord() {
        guard let titleTextField = currentTitleTextField,
              let contentTextView = currentContentTextView,
              let title = titleTextField.text?.trimmingCharacters(in: .whitespaces),
              let content = contentTextView.text?.trimmingCharacters(in: .whitespaces),
              !title.isEmpty,
              !content.isEmpty else {
            showErrorMessage("请输入标题和内容")
            return
        }

        addRecord(title: title, content: content)
        dismiss(animated: true)
        currentTitleTextField = nil
        currentContentTextView = nil
        currentPlaceholderLabel = nil
    }

    // 编辑记录相关方法
    @objc private func dismissEditRecord() {
        dismiss(animated: true)
        currentEditingRecord = nil
        currentTitleTextField = nil
        currentContentTextView = nil
    }

    @objc private func saveEditedRecord() {
        guard let record = currentEditingRecord,
              let titleTextField = currentTitleTextField,
              let contentTextView = currentContentTextView,
              let title = titleTextField.text?.trimmingCharacters(in: .whitespaces),
              let content = contentTextView.text?.trimmingCharacters(in: .whitespaces),
              !title.isEmpty,
              !content.isEmpty else {
            showErrorMessage("请输入标题和内容")
            return
        }

        updateRecord(record, newTitle: title, newContent: content)
        dismiss(animated: true)
        currentEditingRecord = nil
        currentTitleTextField = nil
        currentContentTextView = nil
    }

    // MARK: - 添加记录
    private func addRecord(title: String, content: String) {
        let record = Record(title: title, content: content, type: .text)
        records.insert(record, at: 0) // 新记录插入到顶部
        
        // 刷新表格
        tableView.reloadData()
        updateEmptyState()
        
        // 保存数据
        saveRecords()
        
        // 显示成功提示
        showSuccessMessage("记录已保存")
    }
    
    // MARK: - 显示成功消息
    private func showSuccessMessage(_ message: String) {
        let alert = UIAlertController(title: "✅", message: message, preferredStyle: .alert)
        present(alert, animated: true)
        
        // 1秒后自动消失
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            alert.dismiss(animated: true)
        }
    }
    
    // MARK: - 显示错误消息
    private func showErrorMessage(_ message: String) {
        let alert = UIAlertController(title: "❌", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        present(alert, animated: true)
    }

    // MARK: - 导航栏更新
    private func updateNavigationBar() {
        if isSearching {
            // 搜索状态：显示返回按钮和搜索状态
            title = "搜索结果"
            navigationItem.leftBarButtonItem = UIBarButtonItem(
                title: "返回全部",
                style: .plain,
                target: self,
                action: #selector(showAllRecords)
            )
            navigationItem.rightBarButtonItem = UIBarButtonItem(
                image: UIImage(systemName: "magnifyingglass"),
                style: .plain,
                target: self,
                action: #selector(searchButtonTapped)
            )
        } else {
            // 正常状态：只显示搜索按钮
            title = "记录"
            navigationItem.leftBarButtonItem = nil
            navigationItem.rightBarButtonItem = UIBarButtonItem(
                image: UIImage(systemName: "magnifyingglass"),
                style: .plain,
                target: self,
                action: #selector(searchButtonTapped)
            )
        }
    }

    @objc private func showAllRecords() {
        records = allRecords
        isSearching = false
        updateNavigationBar()
        tableView.reloadData()
        updateEmptyState()
        showSuccessMessage("已显示全部记录")
    }

    // MARK: - 数据持久化
    private func saveRecords() {
        // 如果在搜索状态，保存allRecords；否则保存records
        let recordsToSave = isSearching ? allRecords : records
        DataManager.shared.saveRecords(recordsToSave)
    }

    private func loadRecords() {
        let loadedRecords = DataManager.shared.loadRecords()

        DispatchQueue.main.async {
            self.allRecords = loadedRecords
            self.records = loadedRecords
            self.isSearching = false
            self.updateNavigationBar()
            self.tableView.reloadData()
            self.updateEmptyState()
        }
    }
}

// MARK: - UITableViewDataSource
extension RecordViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return records.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecordCell", for: indexPath) as! RecordTableViewCell
        let record = records[indexPath.row]
        cell.configure(with: record)
        return cell
    }
}

// MARK: - UITableViewDelegate
extension RecordViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        let record = records[indexPath.row]
        showRecordDetail(record)
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let recordToDelete = records[indexPath.row]

            // 从当前显示的记录中删除
            records.remove(at: indexPath.row)

            // 从所有记录中也删除
            if let allIndex = allRecords.firstIndex(where: { $0.id == recordToDelete.id }) {
                allRecords.remove(at: allIndex)
            }

            // 删除表格行
            tableView.deleteRows(at: [indexPath], with: .fade)

            // 更新空状态
            updateEmptyState()

            // 保存数据（保存allRecords，因为它包含完整数据）
            DataManager.shared.saveRecords(allRecords)

            showSuccessMessage("记录已删除")
        }
    }

    private func showRecordDetail(_ record: Record) {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "yyyy年M月d日 HH:mm"

        let message = "\(record.content)\n\n创建时间: \(formatter.string(from: record.date))"

        let alert = UIAlertController(title: record.title, message: message, preferredStyle: .alert)

        // 添加编辑选项
        alert.addAction(UIAlertAction(title: "编辑", style: .default) { _ in
            self.editRecord(record)
        })

        alert.addAction(UIAlertAction(title: "确定", style: .default))

        present(alert, animated: true)
    }

    // MARK: - 搜索功能
    private func showSearchAlert() {
        let alert = UIAlertController(title: "搜索记录", message: nil, preferredStyle: .alert)

        alert.addTextField { textField in
            textField.placeholder = "输入搜索关键词"
            textField.clearButtonMode = .whileEditing
        }

        alert.addAction(UIAlertAction(title: "搜索", style: .default) { _ in
            guard let textField = alert.textFields?.first,
                  let keyword = textField.text,
                  !keyword.trimmingCharacters(in: .whitespaces).isEmpty else {
                return
            }

            self.searchRecords(keyword: keyword)
        })

        alert.addAction(UIAlertAction(title: "显示全部", style: .default) { _ in
            self.loadRecords()
        })

        alert.addAction(UIAlertAction(title: "取消", style: .cancel))

        present(alert, animated: true)
    }

    // MARK: - 搜索记录
    private func searchRecords(keyword: String) {
        // 确保有最新的数据
        allRecords = DataManager.shared.loadRecords()

        let filteredRecords = allRecords.filter { record in
            record.title.localizedCaseInsensitiveContains(keyword) ||
            record.content.localizedCaseInsensitiveContains(keyword)
        }

        records = filteredRecords
        isSearching = true
        updateNavigationBar()
        tableView.reloadData()
        updateEmptyState()

        if filteredRecords.isEmpty {
            showErrorMessage("没有找到包含 \"\(keyword)\" 的记录")
        } else {
            showSuccessMessage("找到 \(filteredRecords.count) 条记录")
        }
    }

    // MARK: - 编辑记录
    private func editRecord(_ record: Record) {
        let editRecordVC = UIViewController()
        editRecordVC.modalPresentationStyle = .pageSheet
        editRecordVC.view.backgroundColor = .systemBackground

        // 创建导航栏
        let navBar = UINavigationBar()
        navBar.translatesAutoresizingMaskIntoConstraints = false

        let navItem = UINavigationItem(title: "编辑记录")
        let cancelButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(dismissEditRecord))
        let saveButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveEditedRecord))

        navItem.leftBarButtonItem = cancelButton
        navItem.rightBarButtonItem = saveButton
        navBar.setItems([navItem], animated: false)

        // 创建标题输入框（单行）
        let titleTextField = UITextField()
        titleTextField.text = record.title
        titleTextField.placeholder = "输入记录标题"
        titleTextField.borderStyle = .roundedRect
        titleTextField.font = UIFont.systemFont(ofSize: 20)
        titleTextField.translatesAutoresizingMaskIntoConstraints = false

        // 创建内容输入框（多行，但不要太大）
        let contentTextView = UITextView()
        contentTextView.text = record.content
        contentTextView.font = UIFont.systemFont(ofSize: 20)
        contentTextView.layer.borderColor = UIColor.systemGray4.cgColor
        contentTextView.layer.borderWidth = 1
        contentTextView.layer.cornerRadius = 8
        contentTextView.translatesAutoresizingMaskIntoConstraints = false

        // 添加到视图
        editRecordVC.view.addSubview(navBar)
        editRecordVC.view.addSubview(titleTextField)
        editRecordVC.view.addSubview(contentTextView)

        // 设置约束 - 内容输入框适中大小，不占满整个屏幕
        NSLayoutConstraint.activate([
            navBar.topAnchor.constraint(equalTo: editRecordVC.view.safeAreaLayoutGuide.topAnchor),
            navBar.leadingAnchor.constraint(equalTo: editRecordVC.view.leadingAnchor),
            navBar.trailingAnchor.constraint(equalTo: editRecordVC.view.trailingAnchor),

            titleTextField.topAnchor.constraint(equalTo: navBar.bottomAnchor, constant: 20),
            titleTextField.leadingAnchor.constraint(equalTo: editRecordVC.view.leadingAnchor, constant: 16),
            titleTextField.trailingAnchor.constraint(equalTo: editRecordVC.view.trailingAnchor, constant: -16),
            titleTextField.heightAnchor.constraint(equalToConstant: 44),

            contentTextView.topAnchor.constraint(equalTo: titleTextField.bottomAnchor, constant: 16),
            contentTextView.leadingAnchor.constraint(equalTo: editRecordVC.view.leadingAnchor, constant: 16),
            contentTextView.trailingAnchor.constraint(equalTo: editRecordVC.view.trailingAnchor, constant: -16),
            // 设置适中的高度，不要占满整个屏幕
            contentTextView.heightAnchor.constraint(equalToConstant: 200)
        ])

        // 存储引用以便在保存时使用
        currentEditingRecord = record
        currentTitleTextField = titleTextField
        currentContentTextView = contentTextView

        present(editRecordVC, animated: true) {
            titleTextField.becomeFirstResponder()
        }
    }

    // MARK: - 更新记录
    private func updateRecord(_ oldRecord: Record, newTitle: String, newContent: String) {
        // 找到记录的索引
        guard let index = records.firstIndex(where: { $0.id == oldRecord.id }) else { return }

        // 创建新记录（保持原有的日期和ID）
        let newRecord = Record(
            id: oldRecord.id,
            title: newTitle,
            content: newContent,
            date: oldRecord.date,
            type: oldRecord.type
        )
        records[index] = newRecord

        // 保存数据
        saveRecords()

        // 刷新表格
        tableView.reloadData()

        showSuccessMessage("记录已更新")
    }
}

// MARK: - 记录表格单元格
class RecordTableViewCell: UITableViewCell {

    private let titleLabel = UILabel()
    private let contentLabel = UILabel()
    private let timeLabel = UILabel()
    private let iconImageView = UIImageView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        // 设置图标
        iconImageView.image = UIImage(systemName: "note.text")
        iconImageView.tintColor = .systemGreen
        iconImageView.contentMode = .scaleAspectFit

        // 设置标题标签
        titleLabel.font = .systemFont(ofSize: 24, weight: .medium)
        titleLabel.textColor = .label
        titleLabel.numberOfLines = 1

        // 设置内容标签
        contentLabel.font = .systemFont(ofSize: 20, weight: .regular)
        contentLabel.textColor = .secondaryLabel
        contentLabel.numberOfLines = 2

        // 设置时间标签
        timeLabel.font = .systemFont(ofSize: 18, weight: .regular)
        timeLabel.textColor = .tertiaryLabel

        // 添加到内容视图
        contentView.addSubview(iconImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(contentLabel)
        contentView.addSubview(timeLabel)

        // 设置自动布局
        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        contentLabel.translatesAutoresizingMaskIntoConstraints = false
        timeLabel.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            // 图标约束
            iconImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            iconImageView.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            iconImageView.widthAnchor.constraint(equalToConstant: 24),
            iconImageView.heightAnchor.constraint(equalToConstant: 24),

            // 标题约束
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 12),
            titleLabel.trailingAnchor.constraint(equalTo: timeLabel.leadingAnchor, constant: -8),
            titleLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),

            // 时间约束
            timeLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            timeLabel.topAnchor.constraint(equalTo: titleLabel.topAnchor),
            timeLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 60),

            // 内容约束
            contentLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor),
            contentLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            contentLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            contentLabel.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor, constant: -8)
        ])
    }

    func configure(with record: Record) {
        titleLabel.text = record.title
        contentLabel.text = record.content

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.dateFormat = "M月d日 HH:mm"
        timeLabel.text = formatter.string(from: record.date)

        // 根据类型设置图标
        switch record.type {
        case .text:
            iconImageView.image = UIImage(systemName: "note.text")
            iconImageView.tintColor = .systemGreen
        case .voice:
            iconImageView.image = UIImage(systemName: "mic.fill")
            iconImageView.tintColor = .systemOrange
        }
    }
}

// MARK: - UITextViewDelegate
extension RecordViewController: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        // 控制占位符的显示/隐藏
        currentPlaceholderLabel?.isHidden = !textView.text.isEmpty
    }
}
