import Foundation
import UIKit
import UserNotifications
import AVFoundation

// MARK: - 激进的提醒管理器
class AggressiveReminderManager {
    
    static let shared = AggressiveReminderManager()
    
    private var activeTimers: [String: Timer] = [:]
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    
    private init() {}
    
    // MARK: - 为重要提醒设置激进定时器
    func scheduleAggressiveReminder(id: String, title: String, date: Date) {
        print("🚀 设置激进提醒: \(title)")
        
        // 取消之前的定时器
        cancelAggressiveReminder(id: id)
        
        let timeInterval = date.timeIntervalSinceNow
        
        if timeInterval <= 0 {
            // 时间已到，立即触发
            triggerAggressiveReminder(id: id, title: title)
            return
        }
        
        // 创建定时器
        let timer = Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: false) { [weak self] _ in
            print("⏰ 激进定时器触发: \(title)")
            self?.triggerAggressiveReminder(id: id, title: title)
        }
        
        activeTimers[id] = timer
        
        // 启动后台任务保护
        startBackgroundTaskProtection()
        
        print("✅ 激进定时器已设置，\(Int(timeInterval))秒后触发")
    }
    
    // MARK: - 取消激进提醒
    func cancelAggressiveReminder(id: String) {
        print("🛑 取消激进提醒定时器: \(id)")

        activeTimers[id]?.invalidate()
        activeTimers.removeValue(forKey: id)

        if activeTimers.isEmpty {
            endBackgroundTaskProtection()
            print("🛑 所有激进提醒定时器已清除")
        }
    }

    // MARK: - 取消所有激进提醒
    func cancelAllAggressiveReminders() {
        print("🛑 取消所有激进提醒定时器")

        for (id, timer) in activeTimers {
            timer.invalidate()
            print("🛑 已取消定时器: \(id)")
        }

        activeTimers.removeAll()
        endBackgroundTaskProtection()

        print("✅ 所有激进提醒定时器已清除")
    }
    
    // MARK: - 触发激进提醒
    private func triggerAggressiveReminder(id: String, title: String) {
        print("🚨🚨🚨 激进提醒触发: \(title)")

        // 确保在主线程执行
        DispatchQueue.main.async {
            // 立即播放音乐
            AlarmPlayer.shared.playImportantAlarm(for: id, title: title)

            // 🔥 移除第二个弹窗：不再发送备用通知
            // self.sendBackupNotification(id: id, title: title)
        }

        // 清理定时器
        activeTimers.removeValue(forKey: id)

        if activeTimers.isEmpty {
            endBackgroundTaskProtection()
        }
    }
    
    // 🔥 已删除 sendBackupNotification 方法，不再显示第二个弹窗
    
    // MARK: - 启动后台任务保护
    private func startBackgroundTaskProtection() {
        guard backgroundTask == .invalid else { return }
        
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "AggressiveReminder") { [weak self] in
            print("⚠️ 后台任务即将过期，强制结束")
            self?.endBackgroundTaskProtection()
        }
        
        print("🛡️ 后台任务保护已启动")
    }
    
    // MARK: - 结束后台任务保护
    private func endBackgroundTaskProtection() {
        guard backgroundTask != .invalid else { return }
        
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = .invalid
        
        print("🛡️ 后台任务保护已结束")
    }
    
    // MARK: - 应用进入后台时的处理
    func applicationDidEnterBackground() {
        print("📱 应用进入后台，检查激进定时器")
        
        // 为所有活跃的定时器启动保护
        if !activeTimers.isEmpty {
            startBackgroundTaskProtection()
            
            // 创建一个长期运行的后台任务
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                self?.runBackgroundLoop()
            }
        }
    }
    
    // MARK: - 后台循环检查
    private func runBackgroundLoop() {
        print("🔄 开始后台循环检查")
        
        while !activeTimers.isEmpty && backgroundTask != .invalid {
            // 检查是否有定时器需要触发
            let now = Date()
            
            for (id, timer) in activeTimers {
                if !timer.isValid {
                    print("⏰ 发现失效的定时器: \(id)")
                    activeTimers.removeValue(forKey: id)
                }
            }
            
            // 短暂休眠，避免过度消耗CPU
            Thread.sleep(forTimeInterval: 1.0)
        }
        
        print("🔄 后台循环检查结束")
    }
    
    // MARK: - 清理所有定时器
    func cleanup() {
        for timer in activeTimers.values {
            timer.invalidate()
        }
        activeTimers.removeAll()
        endBackgroundTaskProtection()
        
        print("🧹 激进提醒管理器已清理")
    }
}
