#!/usr/bin/env python3
"""
创建符合iOS规范的通知音频文件
iOS限制：最大30秒，文件大小要合理
"""

import numpy as np
import wave

def create_ios_alarm_sound():
    # 🔥 iOS通知音频限制：最大30秒
    sample_rate = 22050  # 降低采样率减小文件大小
    duration = 30  # 30秒（iOS限制）
    frequency = 1000  # 1000Hz频率，更清晰
    
    # 创建时间轴
    t = np.linspace(0, duration, int(sample_rate * duration), False)
    
    # 创建间歇性响铃模式：0.8秒响，0.2秒停，循环
    beep_duration = 0.8  # 响铃持续时间
    silence_duration = 0.2  # 静音持续时间
    cycle_duration = beep_duration + silence_duration  # 总周期时间
    
    # 生成音频波形
    audio = np.zeros_like(t)
    
    for i, time in enumerate(t):
        cycle_position = time % cycle_duration
        if cycle_position < beep_duration:
            # 在响铃阶段，生成正弦波，添加渐变避免爆音
            fade_in = min(cycle_position / 0.1, 1.0)  # 0.1秒渐入
            fade_out = min((beep_duration - cycle_position) / 0.1, 1.0)  # 0.1秒渐出
            envelope = fade_in * fade_out
            audio[i] = 0.5 * envelope * np.sin(2 * np.pi * frequency * time)
        # 在静音阶段保持为0
    
    # 转换为16位整数
    audio_int = (audio * 32767).astype(np.int16)
    
    # 保存为WAV文件
    with wave.open('ios_alarm.wav', 'w') as wav_file:
        wav_file.setnchannels(1)  # 单声道
        wav_file.setsampwidth(2)  # 16位
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(audio_int.tobytes())
    
    file_size = len(audio_int.tobytes()) / 1024  # KB
    print(f"✅ 创建了30秒iOS兼容响铃音频文件: ios_alarm.wav")
    print(f"📊 文件大小: {file_size:.1f} KB")
    print(f"🔊 符合iOS通知音频规范，确保后台自动响铃")

if __name__ == "__main__":
    create_ios_alarm_sound()
