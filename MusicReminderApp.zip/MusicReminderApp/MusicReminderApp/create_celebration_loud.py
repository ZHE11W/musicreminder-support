#!/usr/bin/env python3
"""
生成“喜庆、更响、更悦耳”的30秒闹铃: celebration_loud.wav
- iOS 通知自定义声音要求: ≤30s、单声道、16-bit PCM、采样率≤48kHz
- 设计: 120BPM，每拍0.5s；下拍为C大三和弦冲击，上拍为高音点缀；强瞬态但避免削波
"""

import numpy as np
import wave


def create_celebration_loud():
    sr = 44100          # 44.1kHz
    dur = 30.0          # 30秒（iOS上限）
    t = np.linspace(0, dur, int(sr * dur), endpoint=False)

    # 节奏参数（120BPM => 每拍0.5秒；30秒=60拍）
    bpm = 120.0
    sec_per_beat = 60.0 / bpm  # 0.5

    # 频率（Hz）- C大三和弦 + 八度 + 高音点缀
    C5, E5, G5 = 523.25, 659.25, 783.99
    C6, G6 = 1046.50, 1567.98

    # 振幅（注意避免削波）
    chord_amp = 0.85
    ping_amp = 0.75

    # 包络：快速起音 + 指数衰减（打击感更强）
    def burst_env(x, length, attack=0.015):
        if x < 0 or x > length:
            return 0.0
        atk = min(attack, length * 0.25)
        dec = max(0.03, length - atk)
        if x < atk:
            return x / atk
        rem = x - atk
        return float(np.exp(-4.0 * rem / dec))

    chord_len = 0.35  # 下拍和弦长度
    ping_len = 0.15   # 上拍短促点缀长度

    y = np.zeros_like(t, dtype=np.float64)
    two_pi = 2.0 * np.pi

    for i, ti in enumerate(t):
        beat_idx = int(ti / sec_per_beat)        # 第几拍
        t_in_beat = ti - beat_idx * sec_per_beat # 拍内时间

        sample = 0.0
        if beat_idx % 2 == 0:
            # 下拍: C大三和弦 + 八度（更厚）
            env = burst_env(t_in_beat, chord_len)
            if env > 0:
                s1 = np.sin(two_pi * C5 * ti)
                s2 = np.sin(two_pi * E5 * ti)
                s3 = np.sin(two_pi * G5 * ti)
                s4 = np.sin(two_pi * C6 * ti)
                sample += env * chord_amp * (s1 + s2 + s3 + s4) / 4.0
        else:
            # 上拍: 高音短促撞击
            env = burst_env(t_in_beat, ping_len)
            if env > 0:
                s1 = np.sin(two_pi * C6 * ti)
                s2 = np.sin(two_pi * G6 * ti)
                sample += env * ping_amp * (s1 + s2) / 2.0

        # 轻微节奏起伏（2Hz）让整体更“活”
        sample *= (1.0 + 0.08 * np.sin(two_pi * 2.0 * ti))

        # 防止削波
        if sample > 1.0:
            sample = 1.0
        if sample < -1.0:
            sample = -1.0

        y[i] = sample

    # 整体淡入淡出，避免首尾“砰”的爆音
    fade = int(sr * 0.2)
    if fade > 0:
        y[:fade] *= np.linspace(0.0, 1.0, fade)
        y[-fade:] *= np.linspace(1.0, 0.0, fade)

    # 转16-bit PCM 单声道
    audio_int16 = (y * 32767.0).astype(np.int16)

    # 写入 WAV 到项目目录（需手动加入 Xcode Target 才能作为通知声音）
    out_path = 'MusicReminderApp/celebration_loud.wav'
    with wave.open(out_path, 'w') as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(sr)
        f.writeframes(audio_int16.tobytes())

    print('✅ 已生成 30s 喜庆响亮铃声:', out_path)
    print('🔊 规格: 44.1kHz, 16-bit, 单声道, 时长30s')
    print('📌 记得将该文件拖入 Xcode 并勾选 Add to Targets（通知要从 App Bundle 播放）')


if __name__ == '__main__':
    create_celebration_loud()

