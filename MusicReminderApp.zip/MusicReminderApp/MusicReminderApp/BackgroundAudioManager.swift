import Foundation
import AVFoundation
import UIKit

// MARK: - 后台音频管理器
class BackgroundAudioManager {
    
    static let shared = BackgroundAudioManager()
    
    private var backgroundAudioPlayer: AVAudioPlayer?
    private var silentAudioTimer: Timer?
    private var handledDeliveredReminderIDs = Set<String>()

    private init() {}

    // MARK: - 启动后台音频保持（合规方式）
    func startBackgroundAudioKeepAlive() {
        print("🔊 配置后台音频会话（不播放静默音频）")

        // 只配置音频会话，不播放静默音频（避免App Store拒绝）
        do {
            let audioSession = AVAudioSession.sharedInstance()
            // ✅ 改为允许与其他音频混音，确保在刷视频等场景依然保持后台活跃
            try audioSession.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try audioSession.setActive(true)

            print("✅ 后台音频会话配置成功（mixWithOthers启用）")

            // 启动静默音频以保持后台运行（极低音量/静音，合规风险由你确认）
            startSilentAudioPlayback()

            // 🔥 立即检查提醒，然后每10秒检查一次
            checkForUpcomingImportantReminders()

            // 设置定期检查
            Timer.scheduledTimer(withTimeInterval: 10.0, repeats: true) { [weak self] _ in
                self?.checkForUpcomingImportantReminders()
            }

        } catch {
            print("❌ 后台音频会话配置失败: \(error)")
        }
    }
    
    // MARK: - 播放静默音频
    private func startSilentAudioPlayback() {
        // 创建一个极短的静默音频文件
        createSilentAudioFile { [weak self] audioURL in
            guard let audioURL = audioURL else {
                print("❌ 静默音频文件创建失败")
                return
            }
            
            do {
                self?.backgroundAudioPlayer = try AVAudioPlayer(contentsOf: audioURL)
                self?.backgroundAudioPlayer?.numberOfLoops = -1 // 无限循环
                self?.backgroundAudioPlayer?.volume = 0.01 // 极低音量，确保锁屏下持续播放
                self?.backgroundAudioPlayer?.play()

                print("✅ 静默音频播放开始")

                // 定期检查重要提醒
                self?.startReminderCheck()
                
            } catch {
                print("❌ 静默音频播放失败: \(error)")
            }
        }
    }
    
    // MARK: - 创建静默音频文件
    private func createSilentAudioFile(completion: @escaping (URL?) -> Void) {
        guard let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            completion(nil)
            return
        }
        
        let silentAudioURL = documentsPath.appendingPathComponent("silent.wav")
        
        // 如果文件已存在，直接返回
        if FileManager.default.fileExists(atPath: silentAudioURL.path) {
            completion(silentAudioURL)
            return
        }
        
        // 创建1秒的静默音频
        let audioSettings: [String: Any] = [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVSampleRateKey: 44100.0,
            AVNumberOfChannelsKey: 1,
            AVLinearPCMBitDepthKey: 16,
            AVLinearPCMIsFloatKey: false,
            AVLinearPCMIsBigEndianKey: false
        ]
        
        do {
            let audioFile = try AVAudioFile(forWriting: silentAudioURL, settings: audioSettings)
            
            let sampleRate = 44100.0
            let duration = 1.0 // 1秒
            let frameCount = AVAudioFrameCount(sampleRate * duration)
            
            guard let buffer = AVAudioPCMBuffer(pcmFormat: audioFile.processingFormat, frameCapacity: frameCount) else {
                completion(nil)
                return
            }
            
            buffer.frameLength = frameCount
            
            // 填充静默数据（全部为0）
            if let channelData = buffer.floatChannelData?[0] {
                for i in 0..<Int(frameCount) {
                    channelData[i] = 0.0
                }
            }
            
            try audioFile.write(from: buffer)
            
            print("✅ 静默音频文件创建成功")
            completion(silentAudioURL)
            
        } catch {
            print("❌ 静默音频文件创建失败: \(error)")
            completion(nil)
        }
    }
    
    // MARK: - 开始提醒检查
    private func startReminderCheck() {
        // 每30秒检查一次即将到期的重要提醒
        silentAudioTimer = Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { [weak self] _ in
            self?.checkForUpcomingImportantReminders()
        }
        
        print("⏰ 开始定期检查重要提醒")
    }
    
    // MARK: - 检查即将到期的重要提醒
    private func checkForUpcomingImportantReminders() {
        let center = UNUserNotificationCenter.current()

        // 1) 优先检查刚刚“已送达”的重要提醒（锁屏场景下本地通知已送达但无声）
        center.getDeliveredNotifications { [weak self] notifications in
            guard let self = self else { return }
            let now = Date()
            for delivered in notifications {
                let content = delivered.request.content
                guard content.categoryIdentifier == "IMPORTANT_REMINDER",
                      (content.userInfo["type"] as? String) == "reminder" else { continue }
                let reminderID = (content.userInfo["id"] as? String) ?? delivered.request.identifier
                // 避免重复处理
                if self.handledDeliveredReminderIDs.contains(reminderID) { continue }
                // 仅处理最近120秒内送达的
                let deliveredDate = delivered.date
                if now.timeIntervalSince(deliveredDate) <= 120 {
                    print("🚨 发现刚送达的重要提醒（锁屏）: \(content.title)")
                    self.handledDeliveredReminderIDs.insert(reminderID)
                    DispatchQueue.main.async {
                        self.playImportantReminderMusic(request: delivered.request)
                    }
                }
            }
        }

        // 2) 再检查“即将到点”的待触发重要提醒（日历触发）
        center.getPendingNotificationRequests { [weak self] requests in
            guard let self = self else { return }
            let now = Date()
            for request in requests {
                guard request.content.categoryIdentifier == "IMPORTANT_REMINDER",
                      let trigger = request.trigger as? UNCalendarNotificationTrigger,
                      let triggerDate = Calendar.current.date(from: trigger.dateComponents) else { continue }
                let timeInterval = triggerDate.timeIntervalSince(now)
                if timeInterval <= 5 && timeInterval >= -5 {
                    print("🚨 发现需要触发的重要提醒: \(request.content.title)")
                    DispatchQueue.main.async {
                        self.playImportantReminderMusic(request: request)
                    }
                }
            }
        }
    }
    
    // MARK: - 播放重要提醒音乐
    private func playImportantReminderMusic(request: UNNotificationRequest) {
        let content = request.content

        print("🎵 后台播放重要提醒音乐")

        let userInfo = content.userInfo
        let reminderID = userInfo["id"] as? String ?? "unknown"
        let title = userInfo["title"] as? String ?? "重要提醒"

        // 🔥 后台触发到点，由App内播放器响铃（避免系统通知声被硬件键静音）
        print("🎵 后台触发到点，由App内播放器响铃: \(title)")
        AlarmPlayer.shared.playImportantAlarm(for: reminderID, title: title)
    }
    
    // MARK: - 停止后台音频
    func stopBackgroundAudio() {
        backgroundAudioPlayer?.stop()
        backgroundAudioPlayer = nil
        
        silentAudioTimer?.invalidate()
        silentAudioTimer = nil
        
        print("⏹️ 后台音频已停止")
    }
}
