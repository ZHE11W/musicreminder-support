import Foundation
import AVFoundation
import UIKit
import MediaPlayer

// MARK: - 闹钟播放器
class AlarmPlayer: NSObject {

    static let shared = AlarmPlayer()

    private var audioPlayer: AVAudioPlayer?
    private var currentReminderID: String?
    private var currentReminderTitle: String? // 🔥 存储当前提醒标题
    private var checkTimer: Timer?
    private var systemSoundTimer: Timer?
    private var autoStopTimer: Timer? // 自动停止定时器
    private var lastTriggerTime: Date? // 🔥 防重复触发机制
    private var isAlarmPlaying: Bool = false // 🔥 全局响铃状态

    private override init() {
        super.init()
        setupAudioSession()
        // 暂时禁用定时器，它太激进了
        // startPeriodicCheck()
    }

    // MARK: - 设置音频会话（修复版）
    private func setupAudioSession() {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            // ✅ 允许与其他音频混音，确保在刷视频等场景保持活跃
            try audioSession.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try audioSession.setActive(true)
            print("✅ 音频会话配置成功（mixWithOthers已启用）")
        } catch {
            print("❌ 音频会话配置失败: \(error)")
        }
    }

    // MARK: - 播放重要提醒铃声
    func playImportantAlarm(for reminderID: String, title: String) {
        print("🔥 开始播放重要提醒铃声: \(title)")

        // 如果已经在播放，先停止
        if isAlarmPlaying {
            print("⚠️ 停止当前响铃，开始新的")
            forceStopAllAlarms()
        }

        // 设置状态
        currentReminderID = reminderID
        currentReminderTitle = title
        isAlarmPlaying = true

        // 立即开始播放系统铃声循环（不再使用自定义音频文件）
        print("🔊 启动系统铃声循环")
        startSimpleAlarm(title: title)

        // 设置自动停止
        scheduleAutoStop()

        print("✅ 重要提醒响铃已启动")
    }

    // MARK: - 播放音频文件
    private func startAudioFilePlayback(title: String) {
        guard let audioURL = preferredAlarmURL() else {
            print("❌ 找不到音频文件，使用系统声音")
            startSimpleAlarm(title: title)
            return
        }

        do {
            // 🔥 创建音频播放器
            audioPlayer = try AVAudioPlayer(contentsOf: audioURL)
            audioPlayer?.numberOfLoops = 1  // 播放2次（0=播放1次，1=播放2次）
            audioPlayer?.volume = 1.0
            audioPlayer?.delegate = self

            // 开始播放
            let success = audioPlayer?.play() ?? false
            if success {
                print("✅ 音频文件播放开始: \(audioURL.lastPathComponent)")
            } else {
                print("❌ 音频文件播放失败，使用系统声音")
                startSimpleAlarm(title: title)
            }

        } catch {
            print("❌ 音频播放器创建失败: \(error)，使用系统声音")
            startSimpleAlarm(title: title)
        }
    }

    // 优先使用“celebration_loud”；若不存在则返回nil，由上层改为系统声
    private func preferredAlarmURL() -> URL? {
        // 1) Documents 目录（便于后续替换不发版）
        if let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            let docURL = docs.appendingPathComponent("celebration_loud.wav")
            if FileManager.default.fileExists(atPath: docURL.path) {
                return docURL
            }
        }
        // 2) App Bundle（如果把新文件加入了工程资源）
        if let cafURL = Bundle.main.url(forResource: "celebration_loud", withExtension: "caf") {
            return cafURL
        }
        if let wavURL = Bundle.main.url(forResource: "celebration_loud", withExtension: "wav") {
            return wavURL
        }
        // 3) 无可用文件，返回nil（上层会走系统声音兜底）
        return nil
    }


    // MARK: - 自动停止机制
    private func scheduleAutoStop() {
        // 清除之前的定时器
        autoStopTimer?.invalidate()

        // 1分钟后自动停止，防止用户无法停止
        autoStopTimer = Timer.scheduledTimer(withTimeInterval: 60.0, repeats: false) { [weak self] _ in
            if self?.isPlaying() == true {
                print("⏰ 1分钟自动停止音乐播放 - 标记为错过")

                // 重要提醒自动结束，标记为错过
                if let reminderID = self?.currentReminderID {
                    NotificationCenter.default.post(
                        name: NSNotification.Name("ReminderStatusChanged"),
                        object: nil,
                        userInfo: ["reminderID": reminderID, "status": "missed"]
                    )
                }

                self?.stopAlarm()

                // 显示一个简单的通知告诉用户音乐已停止
                DispatchQueue.main.async {
                    let content = UNMutableNotificationContent()
                    let title = self?.currentReminderTitle ?? "提醒"  // 🔥 使用动态标题
                    content.title = "\(title)已错过"  // 🔥 使用动态标题格式
                    content.body = "1分钟播放时间已到"
                    content.sound = nil

                    let request = UNNotificationRequest(identifier: "auto_stop", content: content, trigger: nil)
                    UNUserNotificationCenter.current().add(request)
                }
            }
        }
    }

    // MARK: - 发送合并的停止通知
    private func sendCombinedStopNotification(title: String) {
        print("📱 发送合并的停止通知")

        let content = UNMutableNotificationContent()
        content.title = "\(title)时间到了，点击停止"  // 🔥 统一格式，移除emoji
        content.body = ""  // 🔥 保持简洁，不显示body
        content.sound = nil  // 不播放声音，避免重复
        content.categoryIdentifier = "STOP_MUSIC"

        // 🔥 使用Critical Alert确保通知显示
        if #available(iOS 15.0, *) {
            content.interruptionLevel = .critical  // 使用最高级别
            content.relevanceScore = 1.0
        }

        // 🔥 关键修复：先移除原通知，再发送新的合并通知
        let notificationID = currentReminderID ?? "important_reminder_playing"

        // 先移除原通知
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [notificationID])
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [notificationID])

        let request = UNNotificationRequest(identifier: notificationID, content: content, trigger: nil)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ 发送合并停止通知失败: \(error)")
            } else {
                print("✅ 合并停止通知已发送，替换原通知，ID: \(notificationID)")
            }
        }

        // 每5秒重新发送一次通知，确保用户能看到
        scheduleRepeatingStopNotification(title: title)
    }

    // MARK: - 保留原方法以兼容其他调用
    private func sendStopMusicNotification() {
        // 这个方法现在调用新的合并方法，使用当前提醒的实际标题
        let title = currentReminderTitle ?? "提醒"  // 🔥 使用实际标题或默认值
        sendCombinedStopNotification(title: title)
    }

    // MARK: - 定期重发合并停止通知
    private func scheduleRepeatingStopNotification(title: String) {
        // 每5秒发送一次合并停止通知，直到音乐停止
        Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] timer in
            guard let self = self, self.isPlaying() else {
                timer.invalidate()
                return
            }

            let content = UNMutableNotificationContent()
            content.title = "\(title)时间到了，点击停止"  // 🔥 统一格式，使用动态title
            content.body = ""  // 🔥 保持简洁，不显示body
            content.sound = nil
            content.categoryIdentifier = "STOP_MUSIC"

            if #available(iOS 15.0, *) {
                content.interruptionLevel = .critical  // 🔥 使用最高级别
            }

            // 🔥 使用当前提醒的ID，这样会更新现有通知而不是创建多个
            let notificationID = self.currentReminderID ?? "important_reminder_playing"
            let request = UNNotificationRequest(identifier: notificationID, content: content, trigger: nil)
            UNUserNotificationCenter.current().add(request)

            print("🔄 重新发送合并停止通知")
        }
    }

    // MARK: - 设置控制中心音乐信息
    private func setupNowPlayingInfo(title: String) {
        print("🎵 设置控制中心音乐信息")

        var nowPlayingInfo = [String: Any]()
        nowPlayingInfo[MPMediaItemPropertyTitle] = "重要提醒音乐"
        nowPlayingInfo[MPMediaItemPropertyArtist] = title
        nowPlayingInfo[MPMediaItemPropertyAlbumTitle] = "醒记提醒"
        nowPlayingInfo[MPNowPlayingInfoPropertyElapsedPlaybackTime] = 0
        nowPlayingInfo[MPMediaItemPropertyPlaybackDuration] = 60.0
        nowPlayingInfo[MPNowPlayingInfoPropertyPlaybackRate] = 1.0

        MPNowPlayingInfoCenter.default().nowPlayingInfo = nowPlayingInfo

        // 设置远程控制事件
        setupRemoteCommandCenter()
    }

    // MARK: - 设置远程控制中心
    private func setupRemoteCommandCenter() {
        let commandCenter = MPRemoteCommandCenter.shared()

        // 启用播放/暂停按钮
        commandCenter.playCommand.isEnabled = false
        commandCenter.pauseCommand.isEnabled = true
        commandCenter.stopCommand.isEnabled = true

        // 设置暂停命令处理
        commandCenter.pauseCommand.addTarget { [weak self] _ in
            print("🎵 用户通过控制中心暂停音乐")
            self?.stopAlarm()
            return .success
        }

        // 设置停止命令处理
        commandCenter.stopCommand.addTarget { [weak self] _ in
            print("🎵 用户通过控制中心停止音乐")
            self?.stopAlarm()
            return .success
        }
    }

    // MARK: - 简单可靠的响铃方法
    private func startSimpleAlarm(title: String) {
        print("🔊 开始系统声音循环响铃")

        // 停止之前的定时器
        systemSoundTimer?.invalidate()

        // 立即播放第一次
        AudioServicesPlaySystemSound(1005)
        print("🔔 播放第1次响铃")

        // 每2秒播放一次，持续60次（2分钟）
        var playCount = 1
        systemSoundTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] timer in
            guard self?.isAlarmPlaying == true, playCount < 60 else {
                timer.invalidate()
                self?.systemSoundTimer = nil
                print("⏹️ 响铃播放完成")
                return
            }

            AudioServicesPlaySystemSound(1005)
            playCount += 1
            print("🔔 播放第\(playCount)次响铃")
        }

        print("✅ 系统声音循环响铃已启动")
    }

    // MARK: - 检查是否正在播放
    func isPlaying() -> Bool {
        return isAlarmPlaying && (systemSoundTimer?.isValid == true || audioPlayer?.isPlaying == true)
    }

    // MARK: - 简化版本：只播放音乐，不显示界面

    // MARK: - 停止闹钟
    func stopAlarm() {
        print("⏹️ 用户手动停止闹钟播放")

        // 保存当前提醒ID用于后续清理
        let stoppedReminderID = currentReminderID

        // 如果是重要提醒被手动停止，标记为完成
        if let reminderID = currentReminderID {
            print("✅ 重要提醒被手动停止，标记为完成: \(reminderID)")
            NotificationCenter.default.post(
                name: NSNotification.Name("ReminderStatusChanged"),
                object: nil,
                userInfo: ["reminderID": reminderID, "status": "completed"]
            )

            // 🔥 关键修复：取消AggressiveReminderManager中的定时器
            AggressiveReminderManager.shared.cancelAggressiveReminder(id: reminderID)
        }

        // 停止音频播放
        audioPlayer?.stop()
        audioPlayer = nil

        // 停止所有定时器
        systemSoundTimer?.invalidate()
        systemSoundTimer = nil
        autoStopTimer?.invalidate()
        autoStopTimer = nil

        // 清除当前提醒ID和标题
        currentReminderID = nil
        currentReminderTitle = nil  // 🔥 清除当前提醒标题
        isAlarmPlaying = false  // 🔥 清除响铃状态

        // 保持后台音频管理器运行，确保后续提醒在后台也能自动播放主铃声
        // BackgroundAudioManager.shared.stopBackgroundAudio()

        // 🔥 清除所有相关的通知（包括合并的通知）
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [
            "stop_music_playing",
            "important_reminder_playing"  // 新的合并通知ID
        ])
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [
            "stop_music_playing",
            "important_reminder_playing"
        ])

        // 清除所有重复的停止通知
        UNUserNotificationCenter.current().getPendingNotificationRequests { requests in
            let stopMusicRequests = requests.filter { $0.identifier.hasPrefix("stop_music_repeat_") }
            let identifiers = stopMusicRequests.map { $0.identifier }
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: identifiers)
        }

        UNUserNotificationCenter.current().getDeliveredNotifications { notifications in
            let stopMusicNotifications = notifications.filter { $0.request.identifier.hasPrefix("stop_music_repeat_") }
            let identifiers = stopMusicNotifications.map { $0.request.identifier }
            UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: identifiers)
        }

        // 清除控制中心音乐信息
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil

        // 禁用远程控制
        let commandCenter = MPRemoteCommandCenter.shared()
        commandCenter.pauseCommand.removeTarget(nil)
        commandCenter.stopCommand.removeTarget(nil)
        commandCenter.pauseCommand.isEnabled = false
        commandCenter.stopCommand.isEnabled = false

        // 通知主界面隐藏停止按钮
        NotificationCenter.default.post(name: NSNotification.Name("HideStopMusicButton"), object: nil)

        print("✅ 闹钟已停止，所有相关管理器已清理，控制中心已清理")
    }

    // MARK: - 清理资源
    deinit {
        checkTimer?.invalidate()
        checkTimer = nil
    }

    // MARK: - 延后闹钟
    private func snoozeAlarm(title: String) {
        stopAlarm()

        // 5分钟后再次提醒
        DispatchQueue.main.asyncAfter(deadline: .now() + 300) { [weak self] in
            self?.playImportantAlarm(for: UUID().uuidString, title: title)
        }

        print("✅ 闹钟已延后5分钟")
    }
}

// MARK: - AVAudioPlayerDelegate
extension AlarmPlayer: AVAudioPlayerDelegate {

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        print("🎵 音频播放完成，成功: \(flag)")

        // 如果还在响铃状态，继续播放（实现循环）
        if isAlarmPlaying && currentReminderID != nil {
            print("🔄 继续循环播放音频")
            if let audioURL = preferredAlarmURL() {
                do {
                    audioPlayer = try AVAudioPlayer(contentsOf: audioURL)
                    audioPlayer?.numberOfLoops = 1
                    audioPlayer?.volume = 1.0
                    audioPlayer?.delegate = self
                    audioPlayer?.play()
                } catch {
                    print("❌ 循环播放失败: \(error)")
                }
            }
        }
    }

    func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        print("❌ 音频播放解码错误: \(error?.localizedDescription ?? "未知错误")")

        // 如果音频解码失败，使用系统声音作为备用
        if isAlarmPlaying && currentReminderID != nil {
            print("🚨 音频文件失败，使用系统声音")
            if let title = currentReminderTitle {
                startSimpleAlarm(title: title)
            }
        }
    }
}

// MARK: - 全局响铃控制
extension AlarmPlayer {

    // MARK: - 强制停止所有响铃
    func forceStopAllAlarms() {
        print("🚨 强制停止所有响铃")

        // 停止所有音频播放
        audioPlayer?.stop()
        audioPlayer = nil

        // 停止所有定时器
        systemSoundTimer?.invalidate()
        systemSoundTimer = nil
        autoStopTimer?.invalidate()
        autoStopTimer = nil
        checkTimer?.invalidate()
        checkTimer = nil

        // 清除所有状态
        currentReminderID = nil
        currentReminderTitle = nil
        isAlarmPlaying = false

        // 确保后台音频保持开启（避免脱离Xcode后被系统挂起）
        BackgroundAudioManager.shared.startBackgroundAudioKeepAlive()

        // 清除控制中心
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil

        print("✅ 所有响铃已强制停止")
    }
}
