import Foundation

// MARK: - 数据管理器
class DataManager {
    
    static let shared = DataManager()
    
    private init() {}
    
    // MARK: - 文件路径
    private var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    }
    
    private var remindersFileURL: URL {
        documentsDirectory.appendingPathComponent("reminders.json")
    }
    
    private var recordsFileURL: URL {
        documentsDirectory.appendingPathComponent("records.json")
    }
    
    // MARK: - 提醒数据管理
    func saveReminders(_ reminders: [Reminder]) {
        do {
            let data = try JSONEncoder().encode(reminders)
            try data.write(to: remindersFileURL)
            print("✅ 提醒数据已保存到: \(remindersFileURL.path)")
        } catch {
            print("❌ 保存提醒数据失败: \(error)")
            // 备用方案：使用UserDefaults
            fallbackSaveReminders(reminders)
        }
    }
    
    func loadReminders() -> [Reminder] {
        do {
            let data = try Data(contentsOf: remindersFileURL)
            let reminders = try JSONDecoder().decode([Reminder].self, from: data)
            print("✅ 提醒数据加载成功，共\(reminders.count)条")
            return reminders.sorted { $0.date < $1.date }
        } catch {
            print("❌ 加载提醒数据失败: \(error)")
            // 备用方案：从UserDefaults加载
            return fallbackLoadReminders()
        }
    }
    
    // MARK: - 记录数据管理
    func saveRecords(_ records: [Record]) {
        do {
            let data = try JSONEncoder().encode(records)
            try data.write(to: recordsFileURL)
            print("✅ 记录数据已保存到: \(recordsFileURL.path)")
        } catch {
            print("❌ 保存记录数据失败: \(error)")
            // 备用方案：使用UserDefaults
            fallbackSaveRecords(records)
        }
    }
    
    func loadRecords() -> [Record] {
        do {
            let data = try Data(contentsOf: recordsFileURL)
            let records = try JSONDecoder().decode([Record].self, from: data)
            print("✅ 记录数据加载成功，共\(records.count)条")
            return records
        } catch {
            print("❌ 加载记录数据失败: \(error)")
            // 备用方案：从UserDefaults加载
            return fallbackLoadRecords()
        }
    }
    
    // MARK: - 备用数据管理（UserDefaults）
    private func fallbackSaveReminders(_ reminders: [Reminder]) {
        do {
            let data = try JSONEncoder().encode(reminders)
            UserDefaults.standard.set(data, forKey: "SavedReminders")
            print("✅ 提醒数据已备用保存到UserDefaults")
        } catch {
            print("❌ 备用保存提醒数据失败: \(error)")
        }
    }
    
    private func fallbackLoadReminders() -> [Reminder] {
        guard let data = UserDefaults.standard.data(forKey: "SavedReminders") else {
            print("📱 没有找到备用提醒数据")
            return []
        }
        
        do {
            let reminders = try JSONDecoder().decode([Reminder].self, from: data)
            print("✅ 备用提醒数据加载成功，共\(reminders.count)条")
            return reminders.sorted { $0.date < $1.date }
        } catch {
            print("❌ 加载备用提醒数据失败: \(error)")
            return []
        }
    }
    
    private func fallbackSaveRecords(_ records: [Record]) {
        do {
            let data = try JSONEncoder().encode(records)
            UserDefaults.standard.set(data, forKey: "SavedRecords")
            print("✅ 记录数据已备用保存到UserDefaults")
        } catch {
            print("❌ 备用保存记录数据失败: \(error)")
        }
    }
    
    private func fallbackLoadRecords() -> [Record] {
        guard let data = UserDefaults.standard.data(forKey: "SavedRecords") else {
            print("📱 没有找到备用记录数据")
            return []
        }
        
        do {
            let records = try JSONDecoder().decode([Record].self, from: data)
            print("✅ 备用记录数据加载成功，共\(records.count)条")
            return records
        } catch {
            print("❌ 加载备用记录数据失败: \(error)")
            return []
        }
    }
    
    // MARK: - 数据迁移和清理
    func migrateDataIfNeeded() {
        // 检查是否需要从UserDefaults迁移到文件存储
        if !FileManager.default.fileExists(atPath: remindersFileURL.path) {
            let reminders = fallbackLoadReminders()
            if !reminders.isEmpty {
                saveReminders(reminders)
                print("✅ 提醒数据已迁移到文件存储")
            }
        }
        
        if !FileManager.default.fileExists(atPath: recordsFileURL.path) {
            let records = fallbackLoadRecords()
            if !records.isEmpty {
                saveRecords(records)
                print("✅ 记录数据已迁移到文件存储")
            }
        }
    }
    
    func clearAllData() {
        // 删除文件
        try? FileManager.default.removeItem(at: remindersFileURL)
        try? FileManager.default.removeItem(at: recordsFileURL)
        
        // 清除UserDefaults
        UserDefaults.standard.removeObject(forKey: "SavedReminders")
        UserDefaults.standard.removeObject(forKey: "SavedRecords")
        
        print("✅ 所有数据已清除")
    }
    
    // MARK: - 数据备份和恢复
    func exportData() -> [String: Any]? {
        let reminders = loadReminders()
        let records = loadRecords()
        
        do {
            let remindersData = try JSONEncoder().encode(reminders)
            let recordsData = try JSONEncoder().encode(records)
            
            return [
                "reminders": remindersData.base64EncodedString(),
                "records": recordsData.base64EncodedString(),
                "exportDate": Date().timeIntervalSince1970,
                "version": "1.0"
            ]
        } catch {
            print("❌ 导出数据失败: \(error)")
            return nil
        }
    }
    
    func importData(_ data: [String: Any]) -> Bool {
        guard let remindersString = data["reminders"] as? String,
              let recordsString = data["records"] as? String,
              let remindersData = Data(base64Encoded: remindersString),
              let recordsData = Data(base64Encoded: recordsString) else {
            print("❌ 导入数据格式错误")
            return false
        }
        
        do {
            let reminders = try JSONDecoder().decode([Reminder].self, from: remindersData)
            let records = try JSONDecoder().decode([Record].self, from: recordsData)
            
            saveReminders(reminders)
            saveRecords(records)
            
            print("✅ 数据导入成功")
            return true
        } catch {
            print("❌ 导入数据失败: \(error)")
            return false
        }
    }
    
    // MARK: - 数据统计
    func getDataStatistics() -> [String: Any] {
        let reminders = loadReminders()
        let records = loadRecords()
        
        let activeReminders = reminders.filter { $0.date > Date() }
        let expiredReminders = reminders.filter { $0.date <= Date() }
        
        return [
            "totalReminders": reminders.count,
            "activeReminders": activeReminders.count,
            "expiredReminders": expiredReminders.count,
            "totalRecords": records.count,
            "dataSize": getDataSize()
        ]
    }
    
    private func getDataSize() -> String {
        let remindersSize = (try? Data(contentsOf: remindersFileURL).count) ?? 0
        let recordsSize = (try? Data(contentsOf: recordsFileURL).count) ?? 0
        let totalSize = remindersSize + recordsSize
        
        if totalSize < 1024 {
            return "\(totalSize) bytes"
        } else if totalSize < 1024 * 1024 {
            return String(format: "%.1f KB", Double(totalSize) / 1024.0)
        } else {
            return String(format: "%.1f MB", Double(totalSize) / (1024.0 * 1024.0))
        }
    }
}
