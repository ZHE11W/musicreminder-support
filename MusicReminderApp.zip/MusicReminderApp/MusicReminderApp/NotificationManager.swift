import UIKit
import UserNotifications
import BackgroundTasks

// MARK: - 通知管理器
class NotificationManager: NSObject {
    
    static let shared = NotificationManager()
    
    private override init() {
        super.init()
        setupNotificationCenter()
        setupNotificationObserver()
    }

    // MARK: - 设置通知中心
    private func setupNotificationCenter() {
        // 🔥 不再设置代理，统一由AppDelegate处理
        // UNUserNotificationCenter.current().delegate = self
        print("📝 NotificationManager初始化完成，代理由AppDelegate统一管理")
    }

    // MARK: - 设置通知观察者
    private func setupNotificationObserver() {
        // 监听应用状态变化
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(applicationDidBecomeActive),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(applicationDidEnterBackground),
            name: UIApplication.didEnterBackgroundNotification,
            object: nil
        )
    }

    @objc private func applicationDidBecomeActive() {
        print("📱 应用变为活跃状态，检查待处理的提醒")
        checkPendingReminders()
    }

    @objc private func applicationDidEnterBackground() {
        print("📱 应用进入后台，准备后台提醒处理")
    }

    // MARK: - 检查待处理的提醒
    private func checkPendingReminders() {
        UNUserNotificationCenter.current().getDeliveredNotifications { notifications in
            for notification in notifications {
                let userInfo = notification.request.content.userInfo
                if let type = userInfo["type"] as? String, type == "reminder" {
                    let isImportant = userInfo["isImportant"] as? Bool ?? false

                    if isImportant {
                        print("🔔 发现已送达的重要提醒通知（Critical Alert会自动播放）")
                        // Critical Alert会自动播放音频，无需额外处理
                    } else {
                        print("📝 发现已送达的普通提醒通知")
                    }
                }
            }
        }
    }
    
    // MARK: - 请求通知权限
    func requestNotificationPermission(completion: @escaping (Bool) -> Void) {
        // 🔥 关键修复：请求Critical Alert权限实现真正的后台响铃
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .criticalAlert]) { granted, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ 通知权限请求失败: \(error)")
                    completion(false)
                } else {
                    print(granted ? "✅ 通知权限已获取（包含Critical Alert）" : "❌ 通知权限被拒绝")
                    completion(granted)
                }
            }
        }
    }
    
    // MARK: - 检查通知权限状态
    func checkNotificationPermission(completion: @escaping (UNAuthorizationStatus) -> Void) {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                completion(settings.authorizationStatus)
            }
        }
    }
    
    // MARK: - 安排提醒通知
    func scheduleReminder(id: String, title: String, body: String, date: Date, completion: @escaping (Bool) -> Void) {
        scheduleReminder(id: id, title: title, body: body, date: date, isImportant: false, completion: completion)
    }

    // MARK: - 安排提醒通知（带重要性标识）
    func scheduleReminder(id: String, title: String, body: String, date: Date, isImportant: Bool, completion: @escaping (Bool) -> Void) {
        // 检查日期是否在未来
        guard date > Date() else {
            print("❌ 提醒时间必须在未来")
            completion(false)
            return
        }

        let content = UNMutableNotificationContent()

        // 🔥 关键修复：统一通知格式，所有提醒都使用相同格式
        content.title = "\(title)时间到了，点击停止"
        content.body = ""  // 保持简洁，不显示body

        if isImportant {

            if #available(iOS 15.0, *) {
                content.interruptionLevel = .critical
                content.relevanceScore = 1.0
                content.sound = .defaultCriticalSound(withAudioVolume: 1.0)
                print("🔊 重要提醒使用系统defaultCritical声音（音量=1.0），主铃声由App内播放，可点击即停")
            } else {
                content.sound = .default
            }
            content.categoryIdentifier = "IMPORTANT_REMINDER"
        } else {
            // 普通提醒：使用默认声音
            content.sound = UNNotificationSound.default
            content.categoryIdentifier = "NORMAL_REMINDER"

            if #available(iOS 15.0, *) {
                content.interruptionLevel = .active
                content.relevanceScore = 0.5
            }

            print("📝 配置普通提醒通知（默认声音）")
        }

        content.badge = nil  // 🔥 移除角标显示
        content.userInfo = [
            "type": "reminder",
            "id": id,
            "title": title,
            "body": body,
            "isImportant": isImportant
        ]

        // 设置触发器
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: date)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)

        // 创建主通知请求
        let request = UNNotificationRequest(identifier: id, content: content, trigger: trigger)

        // 如果是重要提醒，还要创建循环通知确保用户可以随时停止
        var allRequests = [request]

        if isImportant {
            // 第二个30秒提醒：继续采用静音通知 + App内播放（便于点击立即停止）
            let secondAlarmContent = content.mutableCopy() as! UNMutableNotificationContent
            // 第二个30秒也使用Critical声音，保证总计60秒在后台/他App场景下都可响
            if #available(iOS 15.0, *) {
                secondAlarmContent.sound = .defaultCriticalSound(withAudioVolume: 1.0)
            } else {
                secondAlarmContent.sound = .default
            }
            secondAlarmContent.title = "\(title)时间到了，点击停止"

            // 使用基于时间间隔的触发器，避免日历触发在秒级上的不确定性
            let secondInterval = max(1.0, date.timeIntervalSinceNow + 30.0)
            let secondAlarmTrigger = UNTimeIntervalNotificationTrigger(timeInterval: secondInterval, repeats: false)

            let secondAlarmRequest = UNNotificationRequest(
                identifier: "\(id)_second_alarm",
                content: secondAlarmContent,
                trigger: secondAlarmTrigger
            )
            allRequests.append(secondAlarmRequest)

            // 创建30个额外的通知，每2秒一个，总共60秒覆盖
            // 为了防止用户按音量键导致当前30秒音频被静音，后续通知使用系统Critical短音再触发一次响铃
            for i in 1...30 {
                let repeatContent = content.mutableCopy() as! UNMutableNotificationContent
                repeatContent.sound = nil // 后续通知仅弹窗，无任何提示音，避免与主铃声重叠
                repeatContent.title = "\(title)时间到了，点击停止"
                if #available(iOS 15.0, *) {
                    repeatContent.interruptionLevel = .active // 明确为非critical，避免系统默认提示音/触发
                }

                // 使用UNTimeIntervalNotificationTrigger以获得更稳定的秒级精度
                let interval = max(1.0, date.timeIntervalSinceNow + TimeInterval(i * 2))
                let repeatTrigger = UNTimeIntervalNotificationTrigger(timeInterval: interval, repeats: false)

                let repeatRequest = UNNotificationRequest(
                    identifier: "\(id)_repeat_\(i)",
                    content: repeatContent,
                    trigger: repeatTrigger
                )
                allRequests.append(repeatRequest)
            }

            print("🔄 为重要提醒创建了\(allRequests.count)个通知（2个30秒响铃 + \(allRequests.count-2)个每2秒循环弹窗）")
        }

        // 添加所有通知
        let group = DispatchGroup()
        var hasError = false

        for request in allRequests {
            group.enter()
            UNUserNotificationCenter.current().add(request) { error in
                if error != nil {
                    hasError = true
                }
                group.leave()
            }
        }

        group.notify(queue: .main) {
            if hasError {
                print("❌ 部分通知安排失败")
                completion(false)
            } else {
                let type = isImportant ? "🔥重要" : "📝普通"
                print("✅ \(type)通知已安排: \(title) at \(date)")
                print("🔧 通知ID: \(id)")
                if isImportant {
                    print("🔧 预期行为: 时间到达时自动播放60秒音频 + 每2秒循环弹窗")
                } else {
                    print("🔧 预期行为: 时间到达时播放系统声音")
                }

                completion(true)
            }
        }
    }



    // MARK: - 取消通知
    func cancelNotification(id: String) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [id])
        print("✅ 已取消通知: \(id)")
    }
    
    // MARK: - 取消所有通知
    func cancelAllNotifications() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        print("✅ 已取消所有通知")
    }
    
    // MARK: - 获取待发送的通知
    func getPendingNotifications(completion: @escaping ([UNNotificationRequest]) -> Void) {
        UNUserNotificationCenter.current().getPendingNotificationRequests { requests in
            DispatchQueue.main.async {
                completion(requests)
            }
        }
    }
    
    // MARK: - 安排延迟提醒
    func scheduleDelayedReminder(title: String, body: String, delayMinutes: Int = 5) {
        let content = UNMutableNotificationContent()
        content.title = "🔔 稍后提醒"
        content.body = body
        content.sound = .default
        content.userInfo = [
            "type": "delayed_reminder",
            "title": title,
            "body": body
        ]
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: TimeInterval(delayMinutes * 60), repeats: false)
        let request = UNNotificationRequest(identifier: "delayed_\(UUID().uuidString)", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ 延迟提醒安排失败: \(error)")
            } else {
                print("✅ 延迟提醒已安排: \(delayMinutes)分钟后")
            }
        }
    }
    
    // MARK: - 显示权限设置提示
    func showPermissionAlert(from viewController: UIViewController) {
        let alert = UIAlertController(
            title: "需要通知权限",
            message: "为了及时提醒您，请在设置中开启通知权限。这样即使应用在后台或被清理，也能正常提醒您。",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "去设置", style: .default) { _ in
            if let settingsUrl = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(settingsUrl)
            }
        })
        
        alert.addAction(UIAlertAction(title: "稍后", style: .cancel))
        
        viewController.present(alert, animated: true)
    }

    // MARK: - 响铃配置调试
    private func logAlarmConfiguration(isImportant: Bool) {
        print("🔧 响铃配置调试:")
        print("  - 提醒类型: \(isImportant ? "重要" : "普通")")
        print("  - 音频文件: celebration_loud.(caf/wav)")
        print("  - Critical Alert: 已启用")
        print("  - 播放方式: 通知使用系统Critical短音 + App内使用系统铃声循环(1005)")
        print("  - 预期行为: 时间到达时自动连续响铃，点击立即停止")

        // 检查通知权限
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            DispatchQueue.main.async {
                print("  - 通知权限状态: \(settings.authorizationStatus.rawValue)")
                print("  - Critical Alert权限: \(settings.criticalAlertSetting.rawValue)")
                print("  - 声音权限: \(settings.soundSetting.rawValue)")
            }
        }
    }
}

// 🔥 NotificationManager只负责安排通知，不处理通知代理
// 所有通知处理都在AppDelegate中统一管理
