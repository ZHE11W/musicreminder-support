#!/usr/bin/env python3
"""
创建更好听的闹钟铃声，类似iPhone默认闹钟
"""

import numpy as np
import wave

def create_better_alarm():
    # iOS规范参数
    sample_rate = 22050  # 22.05kHz
    duration = 30  # 30秒
    
    # 创建时间轴
    t = np.linspace(0, duration, int(sample_rate * duration), False)
    
    # 创建更复杂的和弦铃声（类似iPhone闹钟）
    audio = np.zeros_like(t)
    
    # 主要频率（C大调和弦）
    frequencies = [523.25, 659.25, 783.99]  # C5, E5, G5
    
    # 创建渐进式响铃模式
    beep_duration = 1.0  # 每次响铃1秒
    silence_duration = 0.3  # 静音0.3秒
    cycle_duration = beep_duration + silence_duration
    
    for i, time in enumerate(t):
        cycle_position = time % cycle_duration
        
        if cycle_position < beep_duration:
            # 在响铃阶段，生成和弦
            amplitude = 0.2  # 基础音量
            
            # 添加渐强效果
            fade_in_time = 0.1
            fade_out_time = 0.1
            
            if cycle_position < fade_in_time:
                amplitude *= cycle_position / fade_in_time
            elif cycle_position > beep_duration - fade_out_time:
                amplitude *= (beep_duration - cycle_position) / fade_out_time
            
            # 生成和弦
            for freq in frequencies:
                audio[i] += amplitude * np.sin(2 * np.pi * freq * time) / len(frequencies)
            
            # 添加轻微的颤音效果
            vibrato = 1 + 0.05 * np.sin(2 * np.pi * 6 * time)  # 6Hz颤音
            audio[i] *= vibrato
    
    # 添加整体的音量包络
    envelope = np.ones_like(audio)
    fade_time = int(sample_rate * 0.5)  # 0.5秒淡入淡出
    
    # 淡入
    envelope[:fade_time] = np.linspace(0, 1, fade_time)
    # 淡出
    envelope[-fade_time:] = np.linspace(1, 0, fade_time)
    
    audio *= envelope
    
    # 转换为16位整数
    audio_int = (audio * 32767).astype(np.int16)
    
    # 保存为WAV文件
    with wave.open('MusicReminderApp/pleasant_alarm.wav', 'w') as wav_file:
        wav_file.setnchannels(1)  # 单声道
        wav_file.setsampwidth(2)  # 16位
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(audio_int.tobytes())
    
    file_size = len(audio_int.tobytes()) / 1024  # KB
    print(f"✅ 创建了更好听的闹钟铃声: pleasant_alarm.wav")
    print(f"📊 文件大小: {file_size:.1f} KB")
    print(f"⏱️ 时长: {duration} 秒")
    print(f"🎵 特点: C大调和弦 + 渐强渐弱 + 轻微颤音")
    print(f"🔊 采样率: {sample_rate} Hz")

if __name__ == "__main__":
    create_better_alarm()
