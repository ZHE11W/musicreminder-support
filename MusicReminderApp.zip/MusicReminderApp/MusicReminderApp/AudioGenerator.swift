import Foundation
import AVFoundation

// 音频生成器 - 用于创建持续响铃音频
class AudioGenerator {
    
    static func generateAlarmSound() {
        print("🎵 开始生成持续响铃音频文件...")
        
        // 音频参数
        let sampleRate: Double = 44100
        let duration: Double = 60.0 // 60秒持续响铃
        let frequency: Double = 800 // 800Hz 响铃频率
        
        let frameCount = Int(sampleRate * duration)
        
        // 创建音频缓冲区
        guard let audioBuffer = AVAudioPCMBuffer(pcmFormat: AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!, frameCapacity: AVAudioFrameCount(frameCount)) else {
            print("❌ 无法创建音频缓冲区")
            return
        }
        
        audioBuffer.frameLength = AVAudioFrameCount(frameCount)
        
        // 生成响铃波形（间歇性蜂鸣声）
        guard let samples = audioBuffer.floatChannelData?[0] else {
            print("❌ 无法获取音频数据指针")
            return
        }
        
        for i in 0..<frameCount {
            let time = Double(i) / sampleRate
            
            // 创建间歇性响铃：0.5秒响，0.3秒停，循环
            let cycleTime = time.truncatingRemainder(dividingBy: 0.8) // 0.8秒一个周期
            
            if cycleTime < 0.5 {
                // 响铃阶段：生成正弦波
                let amplitude: Float = 0.8
                samples[i] = amplitude * sin(Float(2.0 * Double.pi * frequency * time))
            } else {
                // 静音阶段
                samples[i] = 0.0
            }
        }
        
        // 保存到文件
        saveAudioBuffer(audioBuffer, to: "alarm_sound.wav")
    }
    
    private static func saveAudioBuffer(_ buffer: AVAudioPCMBuffer, to fileName: String) {
        guard let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            print("❌ 无法获取文档目录")
            return
        }
        
        let audioURL = documentsPath.appendingPathComponent(fileName)
        
        do {
            let audioFile = try AVAudioFile(forWriting: audioURL, settings: buffer.format.settings)
            try audioFile.write(from: buffer)
            print("✅ 音频文件已保存到: \(audioURL.path)")
            
            // 复制到Bundle目录（开发时使用）
            if let bundlePath = Bundle.main.resourcePath {
                let bundleURL = URL(fileURLWithPath: bundlePath).appendingPathComponent(fileName)
                try? FileManager.default.copyItem(at: audioURL, to: bundleURL)
                print("✅ 音频文件已复制到Bundle: \(bundleURL.path)")
            }
            
        } catch {
            print("❌ 保存音频文件失败: \(error)")
        }
    }
}
